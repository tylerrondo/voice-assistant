# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: smoke.spec.ts >> Smoke Suite >> 5. Run All (Automatic) produces a passing verification and a populated log
- Location: tests\playwright\smoke.spec.ts:86:5

# Error details

```
Error: expect(received).toBeGreaterThan(expected)

Expected: > 0
Received:   0
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - heading "Validation Bench" [level=1] [ref=e4]
  - generic [ref=e6]:
    - heading "Test Session" [level=2] [ref=e7]
    - generic [ref=e8]:
      - generic [ref=e9]:
        - generic [ref=e10]: Tester
        - textbox "Tester" [ref=e11]: Tester-1
      - generic [ref=e12]:
        - generic [ref=e13]: UI Language
        - combobox "UI Language" [ref=e14]:
          - option "🇲🇦 الدارجة (ar-MA)"
          - option "🇫🇷 Français (fr-FR)"
          - option "🇬🇧 English (en-US)" [selected]
          - option "🇷🇺 Русский (ru-RU)"
      - generic [ref=e15]:
        - generic [ref=e16]: Voice Language
        - combobox "Voice Language" [ref=e17]:
          - option "🇲🇦 الدارجة (ar-MA)"
          - option "🇫🇷 Français (fr-FR)"
          - option "🇬🇧 English (en-US)" [selected]
          - option "🇷🇺 Русский (ru-RU)"
      - generic [ref=e18]:
        - generic [ref=e19]: Recognition Provider
        - combobox "Recognition Provider" [ref=e20]:
          - option "Browser" [selected]
          - option "OpenAI"
          - option "Azure"
          - option "Google"
          - option "Whisper"
      - generic [ref=e21]:
        - generic [ref=e22]: Speech Provider
        - combobox "Speech Provider" [ref=e23]:
          - option "Browser" [selected]
          - option "OpenAI"
          - option "Azure"
          - option "Google"
      - generic [ref=e24]:
        - generic [ref=e25]: Scenario Set
        - combobox "Scenario Set" [ref=e26]:
          - option "Automatic" [selected]
          - option "Upload"
      - generic [ref=e27]:
        - generic [ref=e28]: Build
        - textbox "Build" [ref=e29]: 1.0.0
      - generic [ref=e30]:
        - generic [ref=e31]: Commit
        - textbox "Commit" [ref=e32]: bafc789
      - generic [ref=e33]:
        - generic [ref=e34]: Environment
        - textbox "Environment" [ref=e35]: demo
      - generic [ref=e36]:
        - generic [ref=e37]: Backend URL
        - textbox "Backend URL" [ref=e38]: https://ibronevik.ru/taxi/c/gruzvill/
      - generic [ref=e39]:
        - generic [ref=e40]: Login
        - textbox "Login" [ref=e41]: testvoiceee@gmail.com
      - generic [ref=e42]:
        - generic [ref=e43]: Password
        - textbox "Password" [ref=e44]: tyler8787
  - generic [ref=e45]: "Backend: — | Mail: —"
  - generic [ref=e47]:
    - text: "Validation Mode:"
    - combobox "Validation Mode:" [ref=e48]:
      - option "Automatic" [selected]
      - option "Interactive"
  - generic [ref=e49]:
    - generic [ref=e50]: "Scenario Source:"
    - generic [ref=e51]:
      - radio "Built-in" [checked] [ref=e52]
      - text: Built-in
    - generic [ref=e53]:
      - radio "JSON File" [ref=e54]
      - text: JSON File
    - generic [ref=e55]:
      - button "Choose File..." [disabled] [ref=e56]
      - generic [ref=e57]: "Scenario File: builtin.json"
  - generic [ref=e58]:
    - generic [ref=e59]:
      - button "Connect" [ref=e60]
      - button "▶ Start" [ref=e61]
      - button "■ Stop" [ref=e62]
      - button "▶ Run All" [ref=e63]
    - generic [ref=e64]: 🎤 Idle
  - generic [ref=e65]:
    - generic [ref=e66]: "Channel State:"
    - text: — |
    - generic [ref=e67]: "Progress:"
    - text: —
  - generic [ref=e68]:
    - heading "Verification" [level=3] [ref=e69]
    - generic [ref=e70]: —
  - heading "Execution Log" [level=3] [ref=e71]
  - heading "Last Completed Report" [level=3] [ref=e73]
  - generic [ref=e74]: Run All or finish an Interactive session to view a report here.
  - heading "JSON Report" [level=3] [ref=e75]
  - heading "Report History" [level=3] [ref=e77]
  - generic [ref=e78]: —
  - generic [ref=e79]:
    - button [ref=e80]
    - button "Upload" [ref=e81] [cursor=pointer]
    - button "Download JSON" [ref=e82]
    - button "Send Report" [ref=e83]
```

# Test source

```ts
  1   | import { test, expect } from "@playwright/test"
  2   | import { setValidationMode, setInputSource, runAll } from "./utils/helpers"
  3   | 
  4   | /**
  5   |  * PR-10 Smoke Suite.
  6   |  *
  7   |  * Design principles (per client review):
  8   |  *  1. Never assert specific hardcoded config values (backend URL,
  9   |  *     tester name, etc.) — only that a field exists, is reachable,
  10  |  *     and its value has a sane format. Defaults can change without
  11  |  *     breaking these tests.
  12  |  *  2. Never assert localized/translatable UI copy. Read structured
  13  |  *     state instead — either the parsed JSON report, or stable
  14  |  *     data-testid/id hooks — so tests don't break when interface
  15  |  *     text changes or gets translated.
  16  |  *  3. Include negative smoke tests: actions attempted before their
  17  |  *     preconditions are met (Next/Repeat before a session has
  18  |  *     started, Download/Send before a report exists) must fail
  19  |  *     safely, not silently succeed or crash.
  20  |  *  4. Prefer asserting state/behavior changes over exact visible
  21  |  *     text, so tests stay resilient to cosmetic UI changes.
  22  |  *
  23  |  * These tests use Automatic mode and Interactive mode with Input
  24  |  * Source = Inject Action, both fully scriptable without a real
  25  |  * microphone (Web Speech API is unavailable/unreliable under
  26  |  * automation) — real-mic behavior is covered by manual QA per the
  27  |  * PR-9d.2 checklist.
  28  |  */
  29  | 
  30  | test.describe("Smoke Suite", () => {
  31  | 
  32  |     test("1. page loads and the app mounts", async ({ page }) => {
  33  |         await page.goto("/")
  34  |         // State-based, not text-based: the root app container exists
  35  |         // and is non-empty, regardless of what heading text it shows.
  36  |         await expect(page.locator("#app")).not.toBeEmpty()
  37  |     })
  38  | 
  39  |     test("2. Session Panel fields exist, are reachable, and have well-formed values", async ({ page }) => {
  40  |         await page.goto("/")
  41  |         // PR-10 fix: no longer asserts specific default values
  42  |         // (e.g. "Tester-1", "en-US", "ibronevik.ru") — only that each
  43  |         // field is present/enabled and its value has a sane shape.
  44  |         const tester = page.getByTestId("session-tester")
  45  |         await expect(tester).toBeEditable()
  46  |         await expect(tester).not.toHaveValue("")
  47  | 
  48  |         const uiLanguage = page.getByTestId("session-ui-language")
  49  |         await expect(uiLanguage).toBeEnabled()
  50  |         expect(await uiLanguage.inputValue()).toMatch(/^[a-z]{2}-[A-Z]{2}$/)
  51  | 
  52  |         const voiceLanguage = page.getByTestId("session-voice-language")
  53  |         await expect(voiceLanguage).toBeEnabled()
  54  |         expect(await voiceLanguage.inputValue()).toMatch(/^[a-z]{2}-[A-Z]{2}$/)
  55  | 
  56  |         const backendUrl = page.getByTestId("session-backend-url")
  57  |         await expect(backendUrl).toBeEditable()
  58  |         expect(await backendUrl.inputValue()).toMatch(/^https?:\/\//)
  59  | 
  60  |         const login = page.getByTestId("session-login")
  61  |         await expect(login).not.toHaveValue("")
  62  | 
  63  |         const password = page.getByTestId("session-password")
  64  |         expect(await password.getAttribute("type")).toBe("password")
  65  |     })
  66  | 
  67  |     test("3. switching to Interactive mode reveals Input Source and Interactive Runner", async ({ page }) => {
  68  |         await page.goto("/")
  69  |         await setValidationMode(page, "interactive")
  70  |         await expect(page.getByTestId("input-source-row")).toBeVisible()
  71  |         await expect(page.getByTestId("interactive-runner")).toBeVisible()
  72  |     })
  73  | 
  74  |     test("4. Input Source toggles Inject/Mic controls correctly", async ({ page }) => {
  75  |         await page.goto("/")
  76  |         await setValidationMode(page, "interactive")
  77  |         await setInputSource(page, "inject")
  78  |         await expect(page.getByTestId("inject-controls")).toBeVisible()
  79  |         await expect(page.getByTestId("mic-controls")).toBeHidden()
  80  | 
  81  |         await setInputSource(page, "mic")
  82  |         await expect(page.getByTestId("mic-controls")).toBeVisible()
  83  |         await expect(page.getByTestId("inject-controls")).toBeHidden()
  84  |     })
  85  | 
  86  |     test("5. Run All (Automatic) produces a passing verification and a populated log", async ({ page }) => {
  87  |         await page.goto("/")
  88  |         await runAll(page)
  89  |         const log = await page.getByTestId("execution-log").innerText()
> 90  |         expect(log.trim().length).toBeGreaterThan(0)
      |                                   ^ Error: expect(received).toBeGreaterThan(expected)
  91  | 
  92  |         const report = JSON.parse(await page.getByTestId("json-report").innerText())
  93  |         expect(report.Summary.failed).toBe(0)
  94  |         expect(report.Summary.passed).toBe(report.Summary.totalScenarios)
  95  | 
  96  |         // PR-10 fix (per client review): compare against the scenario
  97  |         // count the system itself reports, not a hardcoded number —
  98  |         // so this test survives the built-in scenario set growing or
  99  |         // shrinking.
  100 |         const actionCount = (log.match(/\[Action\]/g) ?? []).length
  101 |         expect(actionCount).toBe(report.Summary.totalScenarios)
  102 |     })
  103 | 
  104 |     test("6. required data-testid hooks exist for automated testing", async ({ page }) => {
  105 |         await page.goto("/")
  106 |         for (const testId of [
  107 |             "interactive-runner",
  108 |             "execution-log",
  109 |             "last-report",
  110 |             "manual-comment",
  111 |             "session-state",
  112 |             "current-step",
  113 |             "progress-value",
  114 |             "recognized-text",
  115 |             "speech-text",
  116 |             // PR-11: External JSON Scenarios
  117 |             "scenario-source-builtin",
  118 |             "scenario-source-file",
  119 |             "scenario-file-input",
  120 |             "scenario-choose-file-button",
  121 |             "scenario-file-name",
  122 |             "scenario-error"
  123 |         ]) {
  124 |             await expect(page.getByTestId(testId)).toHaveCount(1)
  125 |         }
  126 |     })
  127 | 
  128 |     test("7. after Run All, the generated report records the current mode configuration", async ({ page }) => {
  129 |         await page.goto("/")
  130 |         // Capture what THIS test actually selected, so the assertion
  131 |         // below compares against real state, not a duplicated literal.
  132 |         const selectedMode = await page.getByTestId("validation-mode").inputValue()
  133 |         await runAll(page)
  134 |         // PR-10 fix: read structured JSON instead of scanning
  135 |         // displayed (potentially localized) text in the report box.
  136 |         const report = JSON.parse(await page.getByTestId("json-report").innerText())
  137 | 
  138 |         // PR-10 fix (per client review): validate against a known set
  139 |         // of allowed values AND against what the test itself set,
  140 |         // instead of a hardcoded "Automatic" literal that would need
  141 |         // manual updates if the mode naming ever changes.
  142 |         const validModes = ["Automatic", "Interactive"]
  143 |         expect(validModes).toContain(report.ValidationMode)
  144 |         expect(report.ValidationMode.toLowerCase()).toBe(selectedMode)
  145 | 
  146 |         expect(typeof report.TestConfiguration.inputSource).toBe("string")
  147 |         expect(report.TestConfiguration.inputSource.length).toBeGreaterThan(0)
  148 |         expect(typeof report.TestConfiguration.recognitionProvider).toBe("string")
  149 |         expect(report.TestConfiguration.recognitionProvider.length).toBeGreaterThan(0)
  150 |     })
  151 | 
  152 |     // ---- Negative smoke tests (per client review, item 3) ----
  153 | 
  154 |     test("8. Next Step is unreachable before an Interactive session has started", async ({ page }) => {
  155 |         await page.goto("/")
  156 |         // Still in Automatic mode: the Interactive Runner (and its
  157 |         // Next Step button) must not be usable at all.
  158 |         await expect(page.getByTestId("interactive-next-button")).toBeHidden()
  159 |     })
  160 | 
  161 |     test("9. Repeat Step is unreachable before an Interactive session has started", async ({ page }) => {
  162 |         await page.goto("/")
  163 |         await expect(page.getByTestId("interactive-repeat-button")).toBeHidden()
  164 |     })
  165 | 
  166 |     test("10. Download Report before any report exists fails safely, not silently", async ({ page }) => {
  167 |         await page.goto("/")
  168 |         // PR-10 fix: a synchronous alert() blocks the renderer, so
  169 |         // click()'s own promise only resolves once the dialog is
  170 |         // dismissed. Racing click() and waitForEvent("dialog") together
  171 |         // in Promise.all still deadlocks, because we can't call
  172 |         // dialog.dismiss() until AFTER Promise.all resolves — which
  173 |         // requires click() to already be done. Registering a
  174 |         // fire-and-forget dialog handler BEFORE clicking avoids this:
  175 |         // it dismisses the dialog independently, letting click() finish.
  176 |         let dialogType: string | null = null
  177 |         page.once("dialog", async (dialog) => {
  178 |             dialogType = dialog.type()
  179 |             await dialog.dismiss()
  180 |         })
  181 |         await page.getByTestId("download-json-button").click()
  182 |         expect(dialogType).toBe("alert")
  183 |     })
  184 | 
  185 |     test("11. Send Report before any report exists fails safely, not silently", async ({ page }) => {
  186 |         await page.goto("/")
  187 |         let dialogType: string | null = null
  188 |         page.once("dialog", async (dialog) => {
  189 |             dialogType = dialog.type()
  190 |             await dialog.dismiss()
```