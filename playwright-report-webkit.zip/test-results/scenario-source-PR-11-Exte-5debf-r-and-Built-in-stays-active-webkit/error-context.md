# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: scenario-source.spec.ts >> PR-11: External JSON Scenarios >> 3. malformed JSON is rejected with an error and Built-in stays active
- Location: tests\playwright\scenario-source.spec.ts:61:5

# Error details

```
Test timeout of 30000ms exceeded.
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - heading "Validation Bench" [level=1] [ref=e4]
  - generic [ref=e6]:
    - heading "Test Session" [level=2] [ref=e7]
    - generic [ref=e8]:
      - generic [ref=e9]:
        - generic [ref=e10]: Tester
        - textbox "Tester" [ref=e11]: Tester-1
      - generic [ref=e12]:
        - generic [ref=e13]: UI Language
        - combobox "UI Language" [ref=e14]:
          - option "🇲🇦 الدارجة (ar-MA)"
          - option "🇫🇷 Français (fr-FR)"
          - option "🇬🇧 English (en-US)" [selected]
          - option "🇷🇺 Русский (ru-RU)"
      - generic [ref=e15]:
        - generic [ref=e16]: Voice Language
        - combobox "Voice Language" [ref=e17]:
          - option "🇲🇦 الدارجة (ar-MA)"
          - option "🇫🇷 Français (fr-FR)"
          - option "🇬🇧 English (en-US)" [selected]
          - option "🇷🇺 Русский (ru-RU)"
      - generic [ref=e18]:
        - generic [ref=e19]: Recognition Provider
        - combobox "Recognition Provider" [ref=e20]:
          - option "Browser" [selected]
          - option "OpenAI"
          - option "Azure"
          - option "Google"
          - option "Whisper"
      - generic [ref=e21]:
        - generic [ref=e22]: Speech Provider
        - combobox "Speech Provider" [ref=e23]:
          - option "Browser" [selected]
          - option "OpenAI"
          - option "Azure"
          - option "Google"
      - generic [ref=e24]:
        - generic [ref=e25]: Scenario Set
        - combobox "Scenario Set" [ref=e26]:
          - option "Automatic" [selected]
          - option "Upload"
      - generic [ref=e27]:
        - generic [ref=e28]: Build
        - textbox "Build" [ref=e29]: 1.0.0
      - generic [ref=e30]:
        - generic [ref=e31]: Commit
        - textbox "Commit" [ref=e32]: bafc789
      - generic [ref=e33]:
        - generic [ref=e34]: Environment
        - textbox "Environment" [ref=e35]: demo
      - generic [ref=e36]:
        - generic [ref=e37]: Backend URL
        - textbox "Backend URL" [ref=e38]: https://ibronevik.ru/taxi/c/gruzvill/
      - generic [ref=e39]:
        - generic [ref=e40]: Login
        - textbox "Login" [ref=e41]: testvoiceee@gmail.com
      - generic [ref=e42]:
        - generic [ref=e43]: Password
        - textbox "Password" [ref=e44]: tyler8787
  - generic [ref=e45]: "Backend: — | Mail: —"
  - generic [ref=e47]:
    - text: "Validation Mode:"
    - combobox "Validation Mode:" [ref=e48]:
      - option "Automatic" [selected]
      - option "Interactive"
  - generic [ref=e49]:
    - generic [ref=e50]: "Scenario Source:"
    - generic [ref=e51]:
      - radio "Built-in" [ref=e52]
      - text: Built-in
    - generic [ref=e53]:
      - radio "JSON File" [checked] [ref=e54]
      - text: JSON File
    - generic [ref=e55]:
      - button "Choose File..." [ref=e56]
      - generic [ref=e57]: "Scenario File: builtin.json"
  - generic [ref=e58]:
    - generic [ref=e59]:
      - button "Connect" [ref=e60]
      - button "▶ Start" [ref=e61]
      - button "■ Stop" [ref=e62]
      - button "▶ Run All" [ref=e63]
    - generic [ref=e64]: 🎤 Idle
  - generic [ref=e65]:
    - generic [ref=e66]: "Channel State:"
    - text: — |
    - generic [ref=e67]: "Progress:"
    - text: —
  - generic [ref=e68]:
    - heading "Verification" [level=3] [ref=e69]
    - generic [ref=e70]: —
  - heading "Execution Log" [level=3] [ref=e71]
  - heading "Last Completed Report" [level=3] [ref=e73]
  - generic [ref=e74]: Run All or finish an Interactive session to view a report here.
  - heading "JSON Report" [level=3] [ref=e75]
  - heading "Report History" [level=3] [ref=e77]
  - generic [ref=e78]: —
  - generic [ref=e79]:
    - button [ref=e80]
    - button "Upload" [ref=e81] [cursor=pointer]
    - button "Download JSON" [ref=e82]
    - button "Send Report" [ref=e83]
```