# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: driver-standard-trip.spec.ts >> PR-13: Driver Standard Trip scenario coverage >> Interactive >> runs the full scenario end to end, updating state after every step
- Location: tests\playwright\driver-standard-trip.spec.ts:124:9

# Error details

```
Error: expect(locator).toHaveAttribute(expected) failed

Locator:  getByTestId('session-state')
Expected: "running"
Received: "idle"
Timeout:  5000ms

Call log:
  - Expect "toHaveAttribute" with timeout 5000ms
  - waiting for getByTestId('session-state')
    13 × locator resolved to <span data-state="idle" id="int-session-state" data-testid="session-state">idle</span>
       - unexpected value "idle"

```

```yaml
- text: idle
```

# Test source

```ts
  33  |  * supposed to be running.
  34  |  *
  35  |  * Per review: state assertions use the `data-state` attribute (the
  36  |  * literal StepState value: idle/running/waiting-tester/finished),
  37  |  * not visible text — that text isn't currently localized either, but
  38  |  * asserting the attribute is the deliberate, stable contract rather
  39  |  * than something that merely happens not to be translated today.
  40  |  * "PASS"/"FAIL" are asserted from the JSON report's Summary.status
  41  |  * field, not the rendered panel text, for the same reason.
  42  |  */
  43  | 
  44  | const __dirname = path.dirname(fileURLToPath(import.meta.url))
  45  | const BUILTIN_SCENARIO_PATH = path.join(
  46  |     __dirname, "..", "..", "packages", "scenario-engine", "src", "scenarios", "builtin.json"
  47  | )
  48  | 
  49  | interface ScenarioSetEntryLike {
  50  |     id?: string
  51  |     name: string
  52  |     trigger?: string
  53  |     activation?: { type: string; value: string }
  54  | }
  55  | interface ScenarioSetLike {
  56  |     id: string
  57  |     name: string
  58  |     scenarios: ScenarioSetEntryLike[]
  59  | }
  60  | 
  61  | function triggerOf(entry: ScenarioSetEntryLike): string {
  62  |     return entry.activation?.value ?? entry.trigger ?? ""
  63  | }
  64  | 
  65  | function loadBuiltinScenarioSet(): ScenarioSetLike {
  66  |     const raw = readFileSync(BUILTIN_SCENARIO_PATH, "utf-8")
  67  |     return JSON.parse(raw)
  68  | }
  69  | 
  70  | // Ground truth for every assertion below — read from the actual file
  71  | // the app ships, not duplicated as literals in this test.
  72  | const BUILTIN_SET = loadBuiltinScenarioSet()
  73  | const TRIGGERS_IN_ORDER = BUILTIN_SET.scenarios.map(triggerOf)
  74  | const TOTAL = TRIGGERS_IN_ORDER.length
  75  | 
  76  | test.describe("PR-13: Driver Standard Trip scenario coverage", () => {
  77  | 
  78  |     test.describe("Automatic", () => {
  79  | 
  80  |         test("runs the full scenario end to end and produces a correct report", async ({ page }) => {
  81  |             await page.goto("/")
  82  |             await setSessionLanguage(page, "en-US")
  83  | 
  84  |             // Precondition: Scenario Source = Built-in, active set = Driver Standard Trip.
  85  |             await expect(page.getByTestId("scenario-source-builtin")).toBeChecked()
  86  |             await expect(page.getByTestId("scenario-file-name")).toHaveText("builtin.json")
  87  |             await expect(page.getByTestId("validation-mode")).toHaveValue("automatic")
  88  | 
  89  |             await runAll(page)
  90  | 
  91  |             // Run All button re-enabling is a stable, non-text signal
  92  |             // that the run has finished (no "Done" text dependency).
  93  |             await expect(page.getByTestId("run-all-button")).toBeEnabled()
  94  | 
  95  |             const report = await readJsonReport(page)
  96  |             assertRequiredReportSections(report)
  97  | 
  98  |             // Cross-check: the report's scenario count actually matches
  99  |             // what's in builtin.json — not just an internally-consistent
  100 |             // number the app made up.
  101 |             expect(report.Summary.totalScenarios).toBe(TOTAL)
  102 | 
  103 |             const logText = await page.getByTestId("execution-log").innerText()
  104 |             assertExecutionLog(report, logText)
  105 |             assertStrictTriggerOrder(logText, TRIGGERS_IN_ORDER)
  106 | 
  107 |             // JSON Report metadata — compared against the file's own
  108 |             // id/name, not literal strings.
  109 |             expect(report.ScenarioSource).toBe("builtin")
  110 |             expect(report.ScenarioId).toBe(BUILTIN_SET.id)
  111 |             expect(report.ScenarioName).toBe(BUILTIN_SET.name)
  112 |             expect(report.ScenarioFile).toBeNull()
  113 | 
  114 |             // PASS for the whole set — from the JSON field, not rendered text.
  115 |             expect(report.Summary.status).toBe("PASS")
  116 |             expect(report.Summary.passed).toBe(TOTAL)
  117 |             expect(report.Summary.failed).toBe(0)
  118 |         })
  119 | 
  120 |     })
  121 | 
  122 |     test.describe("Interactive", () => {
  123 | 
  124 |         test("runs the full scenario end to end, updating state after every step", async ({ page }) => {
  125 |             await page.goto("/")
  126 |             await setSessionLanguage(page, "en-US")
  127 |             await setValidationMode(page, "interactive")
  128 |             await setInputSource(page, "inject")
  129 | 
  130 |             // Selecting Interactive starts the session immediately (no
  131 |             // separate "idle" state to wait through): step 1 is loaded
  132 |             // and the controller is already "running".
> 133 |             await expect(page.getByTestId("session-state")).toHaveAttribute("data-state", "running")
      |                                                             ^ Error: expect(locator).toHaveAttribute(expected) failed
  134 |             await expect(page.getByTestId("current-step")).toHaveText(`1 / ${TOTAL}`)
  135 |             await expect(page.getByTestId("progress-value")).toHaveText("0%")
  136 | 
  137 |             // First "Next Step" click performs step 1 (injects its
  138 |             // action) and moves the controller to "waiting-tester".
  139 |             await page.getByTestId("interactive-next-button").click()
  140 |             await page.getByTestId("manual-recognized-yes-button").waitFor()
  141 |             await expect(page.getByTestId("session-state")).toHaveAttribute("data-state", "waiting-tester")
  142 |             await expect(page.getByTestId("current-step")).toHaveText(`1 / ${TOTAL}`)
  143 | 
  144 |             let logText = await page.getByTestId("execution-log").innerText()
  145 |             expect(logText).toContain(TRIGGERS_IN_ORDER[0])
  146 |             let previousLogLength = countNonEmptyLines(logText)
  147 | 
  148 |             for (let i = 0; i < TOTAL; i++) {
  149 |                 await page.getByTestId("manual-recognized-yes-button").click()
  150 |                 await page.getByTestId("manual-heard-yes-button").click()
  151 |                 await page.getByTestId("interactive-next-button").click()
  152 | 
  153 |                 const isLast = i === TOTAL - 1
  154 | 
  155 |                 if (isLast) {
  156 |                     // Committing the last scenario finishes the session.
  157 |                     await expect(page.getByTestId("session-state")).toHaveAttribute("data-state", "finished")
  158 |                     await expect(page.getByTestId("current-step")).toHaveText(`${TOTAL} / ${TOTAL}`)
  159 |                     await expect(page.getByTestId("progress-value")).toHaveText("100%")
  160 |                 } else {
  161 |                     // Every non-final "Next Step" both commits the
  162 |                     // current scenario AND auto-starts the next one, so
  163 |                     // confirmation buttons for the next step appear
  164 |                     // without an extra click.
  165 |                     await page.getByTestId("manual-recognized-yes-button").waitFor()
  166 |                     await expect(page.getByTestId("session-state")).toHaveAttribute("data-state", "waiting-tester")
  167 |                     await expect(page.getByTestId("current-step")).toHaveText(`${i + 2} / ${TOTAL}`)
  168 |                     await expect(page.getByTestId("progress-value")).toHaveText(`${Math.round((i + 1) / TOTAL * 100)}%`)
  169 |                 }
  170 | 
  171 |                 // Execution Log grew and now contains this step's trigger.
  172 |                 logText = await page.getByTestId("execution-log").innerText()
  173 |                 const currentLogLength = countNonEmptyLines(logText)
  174 |                 expect(currentLogLength).toBeGreaterThan(previousLogLength)
  175 |                 expect(logText).toContain(TRIGGERS_IN_ORDER[i])
  176 |                 previousLogLength = currentLogLength
  177 |             }
  178 | 
  179 |             const report = await readJsonReport(page)
  180 |             expect(report.ScenarioSource).toBe("builtin")
  181 |             expect(report.ScenarioId).toBe(BUILTIN_SET.id)
  182 |             expect(report.ScenarioName).toBe(BUILTIN_SET.name)
  183 |             expect(report.ScenarioFile).toBeNull()
  184 |         })
  185 | 
  186 |     })
  187 | 
  188 |     test("Execution Log preserves strict scenario order in both modes", async ({ page }) => {
  189 |         await page.goto("/")
  190 |         await setSessionLanguage(page, "en-US")
  191 | 
  192 |         await runAll(page)
  193 |         const automaticLog = await page.getByTestId("execution-log").innerText()
  194 |         assertStrictTriggerOrder(automaticLog, TRIGGERS_IN_ORDER)
  195 | 
  196 |         await page.goto("/")
  197 |         await setSessionLanguage(page, "en-US")
  198 |         await setValidationMode(page, "interactive")
  199 |         await setInputSource(page, "inject")
  200 | 
  201 |         for (let i = 0; i < TOTAL; i++) {
  202 |             await page.getByTestId("interactive-next-button").click()
  203 |             await page.getByTestId("manual-recognized-yes-button").waitFor()
  204 |             await page.getByTestId("manual-recognized-yes-button").click()
  205 |             await page.getByTestId("manual-heard-yes-button").click()
  206 |         }
  207 |         await page.getByTestId("interactive-next-button").click()
  208 | 
  209 |         const interactiveLog = await page.getByTestId("execution-log").innerText()
  210 |         assertStrictTriggerOrder(interactiveLog, TRIGGERS_IN_ORDER)
  211 |     })
  212 | 
  213 |     test("running the scenario twice does not leak Execution Log state between runs", async ({ page }) => {
  214 |         await page.goto("/")
  215 |         await setSessionLanguage(page, "en-US")
  216 | 
  217 |         await runAll(page)
  218 |         const firstReport = await readJsonReport(page)
  219 | 
  220 |         await runAll(page)
  221 |         const secondReport = await readJsonReport(page)
  222 |         const secondLog = await page.getByTestId("execution-log").innerText()
  223 | 
  224 |         // Results are consistent across runs.
  225 |         expect(secondReport.Summary.status).toBe(firstReport.Summary.status)
  226 |         expect(secondReport.Summary.totalScenarios).toBe(firstReport.Summary.totalScenarios)
  227 |         expect(secondReport.ScenarioId).toBe(firstReport.ScenarioId)
  228 | 
  229 |         // The second run's live Execution Log is a fresh log with
  230 |         // exactly TOTAL actions, not the first run's entries plus new ones.
  231 |         const secondActionLines = secondLog.split("\n").filter(l => l.includes("[Action]"))
  232 |         expect(secondActionLines.length).toBe(TOTAL)
  233 |         assertStrictTriggerOrder(secondLog, TRIGGERS_IN_ORDER)
```