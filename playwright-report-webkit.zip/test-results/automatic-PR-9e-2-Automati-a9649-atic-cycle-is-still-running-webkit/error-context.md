# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: automatic.spec.ts >> PR-9e.2 Automatic Suite >> 11. Negative scenarios >> blocks a second Run All while the first automatic cycle is still running
- Location: tests\playwright\automatic.spec.ts:223:9

# Error details

```
Error: expect(received).toMatch(expected)

Expected pattern: /^Running scenario \d+ of \d+$/
Received string:  "—"

Call Log:
- Timeout 5000ms exceeded while waiting on the predicate
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - heading "Validation Bench" [level=1] [ref=e4]
  - generic [ref=e6]:
    - heading "Test Session" [level=2] [ref=e7]
    - generic [ref=e8]:
      - generic [ref=e9]:
        - generic [ref=e10]: Tester
        - textbox "Tester" [ref=e11]: Tester-1
      - generic [ref=e12]:
        - generic [ref=e13]: UI Language
        - combobox "UI Language" [ref=e14]:
          - option "🇲🇦 الدارجة (ar-MA)"
          - option "🇫🇷 Français (fr-FR)"
          - option "🇬🇧 English (en-US)" [selected]
          - option "🇷🇺 Русский (ru-RU)"
      - generic [ref=e15]:
        - generic [ref=e16]: Voice Language
        - combobox "Voice Language" [ref=e17]:
          - option "🇲🇦 الدارجة (ar-MA)"
          - option "🇫🇷 Français (fr-FR)"
          - option "🇬🇧 English (en-US)" [selected]
          - option "🇷🇺 Русский (ru-RU)"
      - generic [ref=e18]:
        - generic [ref=e19]: Recognition Provider
        - combobox "Recognition Provider" [ref=e20]:
          - option "Browser" [selected]
          - option "OpenAI"
          - option "Azure"
          - option "Google"
          - option "Whisper"
      - generic [ref=e21]:
        - generic [ref=e22]: Speech Provider
        - combobox "Speech Provider" [ref=e23]:
          - option "Browser" [selected]
          - option "OpenAI"
          - option "Azure"
          - option "Google"
      - generic [ref=e24]:
        - generic [ref=e25]: Scenario Set
        - combobox "Scenario Set" [ref=e26]:
          - option "Automatic" [selected]
          - option "Upload"
      - generic [ref=e27]:
        - generic [ref=e28]: Build
        - textbox "Build" [ref=e29]: 1.0.0
      - generic [ref=e30]:
        - generic [ref=e31]: Commit
        - textbox "Commit" [ref=e32]: bafc789
      - generic [ref=e33]:
        - generic [ref=e34]: Environment
        - textbox "Environment" [ref=e35]: demo
      - generic [ref=e36]:
        - generic [ref=e37]: Backend URL
        - textbox "Backend URL" [ref=e38]: https://ibronevik.ru/taxi/c/gruzvill/
      - generic [ref=e39]:
        - generic [ref=e40]: Login
        - textbox "Login" [ref=e41]: testvoiceee@gmail.com
      - generic [ref=e42]:
        - generic [ref=e43]: Password
        - textbox "Password" [ref=e44]: tyler8787
  - generic [ref=e45]: "Backend: — | Mail: —"
  - generic [ref=e47]:
    - text: "Validation Mode:"
    - combobox "Validation Mode:" [ref=e48]:
      - option "Automatic" [selected]
      - option "Interactive"
  - generic [ref=e49]:
    - generic [ref=e50]: "Scenario Source:"
    - generic [ref=e51]:
      - radio "Built-in" [checked] [ref=e52]
      - text: Built-in
    - generic [ref=e53]:
      - radio "JSON File" [ref=e54]
      - text: JSON File
    - generic [ref=e55]:
      - button "Choose File..." [disabled] [ref=e56]
      - generic [ref=e57]: "Scenario File: builtin.json"
  - generic [ref=e58]:
    - generic [ref=e59]:
      - button "Connect" [ref=e60]
      - button "▶ Start" [ref=e61]
      - button "■ Stop" [ref=e62]
      - button "▶ Run All" [ref=e63]
    - generic [ref=e64]: 🎤 Idle
  - generic [ref=e65]:
    - generic [ref=e66]: "Channel State:"
    - text: — |
    - generic [ref=e67]: "Progress:"
    - text: —
  - generic [ref=e68]:
    - heading "Verification" [level=3] [ref=e69]
    - generic [ref=e70]: —
  - heading "Execution Log" [level=3] [ref=e71]
  - heading "Last Completed Report" [level=3] [ref=e73]
  - generic [ref=e74]: Run All or finish an Interactive session to view a report here.
  - heading "JSON Report" [level=3] [ref=e75]
  - heading "Report History" [level=3] [ref=e77]
  - generic [ref=e78]: —
  - generic [ref=e79]:
    - button [ref=e80]
    - button "Upload" [ref=e81] [cursor=pointer]
    - button "Download JSON" [ref=e82]
    - button "Send Report" [ref=e83]
```

# Test source

```ts
  73  | }
  74  | 
  75  | /** Switches Session Panel UI language (BCP-47 tag). */
  76  | export async function setUiLanguage(page: Page, language: string) {
  77  |     await page.getByTestId("session-ui-language").selectOption(language)
  78  | }
  79  | 
  80  | /** Switches Session Panel voice language (STT/TTS/prompts). */
  81  | export async function setVoiceLanguage(page: Page, language: string) {
  82  |     await page.getByTestId("session-voice-language").selectOption(language)
  83  | }
  84  | 
  85  | /** @deprecated Use setVoiceLanguage for voice or setUiLanguage for UI. */
  86  | export async function setSessionLanguage(page: Page, language: string) {
  87  |     await setVoiceLanguage(page, language)
  88  |     await setUiLanguage(page, language)
  89  | }
  90  | 
  91  | /** Reads the current Session Panel configuration from the UI. */
  92  | export async function readSessionConfig(page: Page): Promise<SessionConfig> {
  93  |     return {
  94  |         tester: await page.getByTestId("session-tester").inputValue(),
  95  |         uiLanguage: await page.getByTestId("session-ui-language").inputValue(),
  96  |         voiceLanguage: await page.getByTestId("session-voice-language").inputValue(),
  97  |         recognitionProvider: await page.getByTestId("session-recognition-provider").inputValue(),
  98  |         speechProvider: await page.getByTestId("session-speech-provider").inputValue(),
  99  |         scenarioSet: await page.getByTestId("session-scenario-set").inputValue(),
  100 |         validationMode: await page.getByTestId("validation-mode").inputValue()
  101 |     }
  102 | }
  103 | 
  104 | /** Parses a public Automatic-mode progress label, if present. */
  105 | export function parseRunningScenarioProgress(text: string): { current: number; total: number } | null {
  106 |     const match = text.match(/^Running scenario (\d+) of (\d+)$/)
  107 |     if (!match) return null
  108 |     return { current: Number(match[1]), total: Number(match[2]) }
  109 | }
  110 | 
  111 | /**
  112 |  * Runs Automatic "Run All" and waits until verification completes.
  113 |  *
  114 |  * Uses run-all-button re-enabling as the completion signal, not
  115 |  * verification-panel's PASS/FAIL text — that text is never cleared
  116 |  * between runs, so on a *second* call within the same test it would
  117 |  * otherwise match the *previous* run's leftover text immediately,
  118 |  * before the new run has actually finished.
  119 |  */
  120 | export async function runAll(page: Page) {
  121 |     await page.getByTestId("run-all-button").click()
  122 |     // PR-13's 5-scenario builtin set includes real `delay` steps, so a
  123 |     // full Automatic run can take longer than Playwright's default 5s
  124 |     // expect() timeout — matches the 30s timeout already used elsewhere
  125 |     // in this file for the same kind of wait.
  126 |     await expect(page.getByTestId("run-all-button")).toBeEnabled({ timeout: 30_000 })
  127 | }
  128 | 
  129 | /**
  130 |  * Runs "Run All" while recording the public #obs-progress text states.
  131 |  */
  132 | export async function runAllWithProgressTracking(page: Page): Promise<string[]> {
  133 |     const snapshots: string[] = []
  134 | 
  135 |     const record = async () => {
  136 |         const text = await page.getByTestId("automatic-progress").innerText()
  137 |         if (snapshots[snapshots.length - 1] !== text) {
  138 |             snapshots.push(text)
  139 |         }
  140 |     }
  141 | 
  142 |     await record()
  143 |     await page.getByTestId("run-all-button").click()
  144 | 
  145 |     await expect.poll(async () => {
  146 |         await record()
  147 |         return await page.getByTestId("automatic-progress").innerText()
  148 |     }, { timeout: 30_000 }).toBe("Done")
  149 | 
  150 |     await record()
  151 |     return snapshots
  152 | }
  153 | 
  154 | /** Asserts Automatic-mode progress follows the public UI state sequence. */
  155 | export function assertAutomaticProgressSequence(states: string[]) {
  156 |     expect(states[0]).toBe("—")
  157 |     expect(states[states.length - 1]).toBe("Done")
  158 |     expect(states).toContain("Done")
  159 | 
  160 |     const runningStates = states.filter((state) => parseRunningScenarioProgress(state) !== null)
  161 |     expect(runningStates.length).toBeGreaterThan(0)
  162 | 
  163 |     const scenarioNumbers = runningStates.map((state) => parseRunningScenarioProgress(state)!.current)
  164 |     for (let i = 1; i < scenarioNumbers.length; i++) {
  165 |         expect(scenarioNumbers[i]).toBeGreaterThanOrEqual(scenarioNumbers[i - 1])
  166 |     }
  167 | }
  168 | 
  169 | /** Waits until Automatic Run All shows an in-progress public progress state. */
  170 | export async function waitForAutomaticRunInProgress(page: Page) {
  171 |     await expect.poll(async () => {
  172 |         return await page.getByTestId("automatic-progress").innerText()
> 173 |     }).toMatch(/^Running scenario \d+ of \d+$/)
      |        ^ Error: expect(received).toMatch(expected)
  174 | }
  175 | 
  176 | /** Counts Action entries currently visible in the Execution Log panel. */
  177 | export async function countActionLogEntries(page: Page): Promise<number> {
  178 |     const logText = await page.getByTestId("execution-log").innerText()
  179 |     return (logText.match(/\[Action\]/g) ?? []).length
  180 | }
  181 | 
  182 | /** Reads the structured JSON report rendered in the public report panel. */
  183 | export async function readJsonReport(page: Page): Promise<ValidationReportJson> {
  184 |     const text = await page.getByTestId("json-report").innerText()
  185 |     expect(text.trim().length).toBeGreaterThan(0)
  186 |     return JSON.parse(text) as ValidationReportJson
  187 | }
  188 | 
  189 | /** Downloads the JSON report through the public Download button. */
  190 | export async function downloadJsonReport(page: Page): Promise<ValidationReportJson> {
  191 |     const [download] = await Promise.all([
  192 |         page.waitForEvent("download"),
  193 |         page.getByTestId("download-json-button").click()
  194 |     ])
  195 |     expect(download.suggestedFilename()).toMatch(/validation-report-.*\.json$/)
  196 |     const filePath = await download.path()
  197 |     expect(filePath).toBeTruthy()
  198 |     const content = await fs.readFile(filePath!, "utf-8")
  199 |     return JSON.parse(content) as ValidationReportJson
  200 | }
  201 | 
  202 | /** Registers a one-shot handler that dismisses the next browser dialog. */
  203 | export function dismissNextDialog(page: Page): Promise<string | null> {
  204 |     return new Promise((resolve) => {
  205 |         page.once("dialog", async (dialog) => {
  206 |             const type = dialog.type()
  207 |             await dialog.dismiss()
  208 |             resolve(type)
  209 |         })
  210 |     })
  211 | }
  212 | 
  213 | /**
  214 |  * Mocks backend endpoints so Send Report can be exercised in CI without
  215 |  * real network credentials. Captures the report payload from the send call.
  216 |  */
  217 | export async function setupBackendMocks(page: Page, capture: { sentReport?: ValidationReportJson }) {
  218 |     await page.route("**/api/v1/auth", async (route) => {
  219 |         await route.fulfill({
  220 |             status: 200,
  221 |             contentType: "application/json",
  222 |             body: JSON.stringify({ auth_hash: "test-auth-hash" })
  223 |         })
  224 |     })
  225 | 
  226 |     await page.route("**/api/v1/token", async (route) => {
  227 |         await route.fulfill({
  228 |             status: 200,
  229 |             contentType: "application/json",
  230 |             body: JSON.stringify({ data: { token: "test-token", u_hash: "test-u-hash" } })
  231 |         })
  232 |     })
  233 | 
  234 |     await page.route("**/api/v1/data/**", async (route) => {
  235 |         await route.fulfill({
  236 |             status: 200,
  237 |             contentType: "application/json",
  238 |             body: JSON.stringify({ data: { data: { site_emails: { "email-1": {} } } } })
  239 |         })
  240 |     })
  241 | 
  242 |     await page.route("**/api/v1/mail/**/send/**", async (route) => {
  243 |         const postData = route.request().postData() ?? ""
  244 |         const params = new URLSearchParams(postData)
  245 |         const fileParam = params.get("file")
  246 | 
  247 |         if (fileParam) {
  248 |             const files = JSON.parse(fileParam) as Array<{ base64: string; name: string }>
  249 |             const base64 = files[0]?.base64?.replace(/^data:.*?;base64,/, "")
  250 |             if (base64) {
  251 |                 capture.sentReport = JSON.parse(
  252 |                     Buffer.from(base64, "base64").toString("utf-8")
  253 |                 ) as ValidationReportJson
  254 |             }
  255 |         }
  256 | 
  257 |         await route.fulfill({ status: 200, body: "{}" })
  258 |     })
  259 | }
  260 | 
  261 | /** Asserts the canonical report sections required by the PR-9e.2 spec. */
  262 | export function assertRequiredReportSections(report: ValidationReportJson) {
  263 |     expect(report.Session).toBeTruthy()
  264 |     expect(report.TestConfiguration).toBeTruthy()
  265 |     expect(report.Summary).toBeTruthy()
  266 |     expect(report.Verification).toBeTruthy()
  267 |     expect(Array.isArray(report.ExecutionLog)).toBe(true)
  268 | }
  269 | 
  270 | /** Asserts Summary and Verification numbers are internally consistent. */
  271 | export function assertSummaryConsistency(report: ValidationReportJson) {
  272 |     const { Summary, Verification } = report
  273 | 
```