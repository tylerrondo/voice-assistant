# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: report.spec.ts >> Report generation >> saved report's ExecutionLog is not affected by starting a new session afterwards
- Location: tests\playwright\report.spec.ts:27:5

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: locator.waitFor: Test timeout of 30000ms exceeded.
Call log:
  - waiting for getByTestId('manual-recognized-yes-button') to be visible
    62 × locator resolved to hidden <button id="int-btn-recognized-yes" data-testid="manual-recognized-yes-button">✓ Correct</button>

```

# Page snapshot

```yaml
- generic [ref=e3]:
  - heading "Validation Bench" [level=1] [ref=e4]
  - generic [ref=e6]:
    - heading "Test Session" [level=2] [ref=e7]
    - generic [ref=e8]:
      - generic [ref=e9]:
        - generic [ref=e10]: Tester
        - textbox "Tester" [ref=e11]: Tester-1
      - generic [ref=e12]:
        - generic [ref=e13]: UI Language
        - combobox "UI Language" [ref=e14]:
          - option "🇲🇦 الدارجة (ar-MA)"
          - option "🇫🇷 Français (fr-FR)"
          - option "🇬🇧 English (en-US)" [selected]
          - option "🇷🇺 Русский (ru-RU)"
      - generic [ref=e15]:
        - generic [ref=e16]: Voice Language
        - combobox "Voice Language" [ref=e17]:
          - option "🇲🇦 الدارجة (ar-MA)"
          - option "🇫🇷 Français (fr-FR)"
          - option "🇬🇧 English (en-US)" [selected]
          - option "🇷🇺 Русский (ru-RU)"
      - generic [ref=e18]:
        - generic [ref=e19]: Recognition Provider
        - combobox "Recognition Provider" [ref=e20]:
          - option "Browser" [selected]
          - option "OpenAI"
          - option "Azure"
          - option "Google"
          - option "Whisper"
      - generic [ref=e21]:
        - generic [ref=e22]: Speech Provider
        - combobox "Speech Provider" [ref=e23]:
          - option "Browser" [selected]
          - option "OpenAI"
          - option "Azure"
          - option "Google"
      - generic [ref=e24]:
        - generic [ref=e25]: Scenario Set
        - combobox "Scenario Set" [ref=e26]:
          - option "Automatic" [selected]
          - option "Upload"
      - generic [ref=e27]:
        - generic [ref=e28]: Build
        - textbox "Build" [ref=e29]: 1.0.0
      - generic [ref=e30]:
        - generic [ref=e31]: Commit
        - textbox "Commit" [ref=e32]: bafc789
      - generic [ref=e33]:
        - generic [ref=e34]: Environment
        - textbox "Environment" [ref=e35]: demo
      - generic [ref=e36]:
        - generic [ref=e37]: Backend URL
        - textbox "Backend URL" [ref=e38]: https://ibronevik.ru/taxi/c/gruzvill/
      - generic [ref=e39]:
        - generic [ref=e40]: Login
        - textbox "Login" [ref=e41]: testvoiceee@gmail.com
      - generic [ref=e42]:
        - generic [ref=e43]: Password
        - textbox "Password" [ref=e44]: tyler8787
  - generic [ref=e45]: "Backend: — | Mail: —"
  - generic [ref=e47]:
    - text: "Validation Mode:"
    - combobox "Validation Mode:" [ref=e48]:
      - option "Automatic"
      - option "Interactive" [selected]
  - generic [ref=e49]:
    - generic [ref=e50]: "Scenario Source:"
    - generic [ref=e51]:
      - radio "Built-in" [checked] [ref=e52]
      - text: Built-in
    - generic [ref=e53]:
      - radio "JSON File" [ref=e54]
      - text: JSON File
    - generic [ref=e55]:
      - button "Choose File..." [disabled] [ref=e56]
      - generic [ref=e57]: "Scenario File: builtin.json"
  - generic [ref=e59]:
    - text: "Input Source:"
    - combobox "Input Source:" [ref=e60]:
      - option "🎤 Browser microphone"
      - option "Inject Action (debug)" [selected]
  - generic [ref=e61]:
    - generic [ref=e62]:
      - button "Connect" [ref=e63]
      - button "▶ Start" [ref=e64]
      - button "■ Stop" [ref=e65]
      - button "▶ Run All" [ref=e66]
    - generic [ref=e67]:
      - generic [ref=e68]:
        - text: "Inject action:"
        - combobox "Inject action:" [ref=e69]:
          - option "voice.accept-order" [selected]
          - option "voice.arrived"
          - option "voice.start-trip"
          - option "voice.finish-trip"
          - option "voice.available"
      - button "Send" [ref=e70]
  - generic [ref=e71]:
    - generic [ref=e72]: "Channel State:"
    - text: — |
    - generic [ref=e73]: "Progress:"
    - text: —
  - generic [ref=e74]:
    - heading "Interactive Runner" [level=3] [ref=e75]
    - generic [ref=e76]:
      - generic [ref=e77]: "Session State:"
      - text: finished |
      - generic [ref=e78]: "Scenario:"
      - text: 0 / 0 |
      - generic [ref=e79]: "Progress:"
      - text: 100%
    - generic [ref=e80]:
      - generic [ref=e81]: Step
      - generic [ref=e82]: All scenarios completed.
      - generic [ref=e83]: "Recognized: —"
      - generic [ref=e84]: "Speech: interaction.unhandled-action"
    - generic [ref=e85]:
      - button "▶ Start Step" [disabled] [ref=e86]
      - button "↺ Repeat Step" [disabled] [ref=e87]
      - button "⏭ Skip Step" [disabled] [ref=e88]
      - button "⏸ Pause" [disabled] [ref=e89]
      - button "⏵ Resume" [disabled] [ref=e90]
    - generic [ref=e91]:
      - generic [ref=e92]: Session Summary
      - generic [ref=e93]:
        - generic [ref=e94]: "Total scenarios: 1"
        - generic [ref=e95]: "Fully confirmed: 1"
        - generic [ref=e96]: "With mismatches: 0"
        - generic [ref=e97]: "Repeats: 0"
        - generic [ref=e98]: "Skipped: 0"
      - button "↻ Start New Session" [ref=e99]
  - generic [ref=e100]:
    - heading "Verification" [level=3] [ref=e101]
    - generic [ref=e102]: —
  - heading "Execution Log" [level=3] [ref=e103]
  - generic [ref=e104]: "[Action] {\"payload\":{}} [Event] {\"type\":\"interaction.unhandled-action\",\"payload\":{}} [Speak] {\"text\":\"interaction.unhandled-action\"}"
  - heading "Last Completed Report" [level=3] [ref=e105]
  - generic [ref=e107]:
    - generic [ref=e108]: "Generated at: 8/3/2026, 12:40:24 PM"
    - generic [ref=e109]:
      - strong [ref=e110]: "Status:"
      - text: PASS
    - generic [ref=e111]:
      - strong [ref=e112]: "Tester:"
      - text: Tester-1 |
      - strong [ref=e113]: "UI Language:"
      - text: en-US |
      - strong [ref=e114]: "Voice Language:"
      - text: en-US
    - generic [ref=e115]:
      - strong [ref=e116]: "Mode:"
      - text: Interactive |
      - strong [ref=e117]: "Input Source:"
      - text: inject
    - generic [ref=e118]:
      - strong [ref=e119]: "Recognition:"
      - text: Browser |
      - strong [ref=e120]: "Speech:"
      - text: Browser |
      - strong [ref=e121]: "Scenario Set:"
      - text: automatic
    - generic [ref=e122]:
      - strong [ref=e123]: "Scenarios:"
      - text: "1 (Passed: 1, Failed: 0)"
    - generic [ref=e124]:
      - strong [ref=e125]: "Duration:"
      - text: 1230 ms
  - heading "JSON Report" [level=3] [ref=e126]
  - generic [ref=e127]: "{ \"Session\": { \"tester\": \"Tester-1\", \"language\": \"en-US\", \"uiLanguage\": \"en-US\", \"startedAt\": \"2026-08-03T07:40:22.962Z\" }, \"Environment\": { \"env\": \"demo\", \"backendUrl\": \"https://ibronevik.ru/taxi/c/gruzvill\" }, \"TestConfiguration\": { \"recognitionProvider\": \"Browser\", \"speechProvider\": \"Browser\", \"scenarioSet\": \"automatic\", \"inputSource\": \"inject\" }, \"ValidationMode\": \"Interactive\", \"ScenarioSource\": \"builtin\", \"ScenarioId\": \"driver-standard-trip\", \"ScenarioName\": \"Driver Standard Trip\", \"ScenarioFile\": null, \"ScenarioStatistics\": { \"total\": 1 }, \"Verification\": { \"totalScenarios\": 1, \"passed\": 1, \"failed\": 0, \"errors\": [] }, \"ManualValidation\": { \"results\": [ { \"step\": 1, \"recognizedText\": null, \"recognizedCorrectly\": true, \"speechPlayed\": true, \"speechText\": \"interaction.unhandled-action\", \"comment\": \"\", \"repeat\": 0, \"skipped\": false, \"durationMs\": 12 } ], \"warnings\": 0, \"repeatedSteps\": 0, \"skippedSteps\": 0 }, \"ExecutionLog\": [ { \"timestamp\": \"2026-08-03T07:40:23.499Z\", \"kind\": \"Action\", \"payload\": { \"payload\": {} } }, { \"timestamp\": \"2026-08-03T07:40:23.505Z\", \"kind\": \"Event\", \"payload\": { \"type\": \"interaction.unhandled-action\", \"payload\": {} } }, { \"timestamp\": \"2026-08-03T07:40:23.507Z\", \"kind\": \"Speak\", \"payload\": { \"text\": \"interaction.unhandled-action\" } } ], \"Summary\": { \"status\": \"PASS\", \"totalScenarios\": 1, \"passed\": 1, \"failed\": 0, \"manualWarnings\": 0, \"repeatedSteps\": 0, \"skippedSteps\": 0, \"durationMs\": 1230 }, \"Attachments\": [] }"
  - heading "Report History" [level=3] [ref=e128]
  - generic [ref=e130]: PASS — 8/3/2026, 12:40:24 PM — Tester-1
  - generic [ref=e131]:
    - button [ref=e132]
    - button "Upload" [ref=e133] [cursor=pointer]
    - button "Download JSON" [ref=e134]
    - button "Send Report" [ref=e135]
```

# Test source

```ts
  238 |             body: JSON.stringify({ data: { data: { site_emails: { "email-1": {} } } } })
  239 |         })
  240 |     })
  241 | 
  242 |     await page.route("**/api/v1/mail/**/send/**", async (route) => {
  243 |         const postData = route.request().postData() ?? ""
  244 |         const params = new URLSearchParams(postData)
  245 |         const fileParam = params.get("file")
  246 | 
  247 |         if (fileParam) {
  248 |             const files = JSON.parse(fileParam) as Array<{ base64: string; name: string }>
  249 |             const base64 = files[0]?.base64?.replace(/^data:.*?;base64,/, "")
  250 |             if (base64) {
  251 |                 capture.sentReport = JSON.parse(
  252 |                     Buffer.from(base64, "base64").toString("utf-8")
  253 |                 ) as ValidationReportJson
  254 |             }
  255 |         }
  256 | 
  257 |         await route.fulfill({ status: 200, body: "{}" })
  258 |     })
  259 | }
  260 | 
  261 | /** Asserts the canonical report sections required by the PR-9e.2 spec. */
  262 | export function assertRequiredReportSections(report: ValidationReportJson) {
  263 |     expect(report.Session).toBeTruthy()
  264 |     expect(report.TestConfiguration).toBeTruthy()
  265 |     expect(report.Summary).toBeTruthy()
  266 |     expect(report.Verification).toBeTruthy()
  267 |     expect(Array.isArray(report.ExecutionLog)).toBe(true)
  268 | }
  269 | 
  270 | /** Asserts Summary and Verification numbers are internally consistent. */
  271 | export function assertSummaryConsistency(report: ValidationReportJson) {
  272 |     const { Summary, Verification } = report
  273 | 
  274 |     expect(Summary.totalScenarios).toBe(Verification.totalScenarios)
  275 |     expect(Summary.passed).toBe(Verification.passed)
  276 |     expect(Summary.failed).toBe(Verification.failed)
  277 |     expect(Summary.passed + Summary.failed + Summary.skippedSteps).toBe(Summary.totalScenarios)
  278 |     expect(Summary.durationMs).toBeGreaterThanOrEqual(0)
  279 |     expect(typeof Summary.status).toBe("string")
  280 |     expect(Summary.status.length).toBeGreaterThan(0)
  281 | }
  282 | 
  283 | /** Asserts Session configuration values were copied into the report. */
  284 | export function assertConfigurationMatchesSession(
  285 |     report: ValidationReportJson,
  286 |     config: SessionConfig
  287 | ) {
  288 |     expect(report.Session.language).toBe(config.voiceLanguage)
  289 |     expect(report.Session.uiLanguage).toBe(config.uiLanguage)
  290 |     expect(report.TestConfiguration.recognitionProvider).toBe(config.recognitionProvider)
  291 |     expect(report.TestConfiguration.speechProvider).toBe(config.speechProvider)
  292 |     expect(report.TestConfiguration.scenarioSet).toBe(config.scenarioSet)
  293 |     expect(report.ValidationMode.toLowerCase()).toBe(config.validationMode)
  294 |     expect(report.TestConfiguration.inputSource).toBe("inject")
  295 | }
  296 | 
  297 | /** Asserts Execution Log ordering and cardinality for Automatic mode. */
  298 | export function assertExecutionLog(report: ValidationReportJson, logText: string) {
  299 |     expect(report.ExecutionLog.length).toBeGreaterThan(0)
  300 | 
  301 |     const lines = logText.split("\n").filter((line) => line.trim().length > 0)
  302 |     const actionLines = lines.filter((line) => line.includes("[Action]"))
  303 |     expect(actionLines.length).toBe(report.Summary.totalScenarios)
  304 | 
  305 |     for (const trigger of SCENARIO_TRIGGERS.slice(0, report.Summary.totalScenarios)) {
  306 |         expect(logText).toContain(trigger)
  307 | 
  308 |         const matchingActions = actionLines.filter((line) => line.includes(trigger))
  309 |         expect(matchingActions.length).toBe(1)
  310 |     }
  311 | 
  312 |     let lastActionIndex = -1
  313 |     for (const trigger of SCENARIO_TRIGGERS.slice(0, report.Summary.totalScenarios)) {
  314 |         const actionIndex = lines.findIndex((line) => line.includes("[Action]") && line.includes(trigger))
  315 |         expect(actionIndex).toBeGreaterThan(lastActionIndex)
  316 |         lastActionIndex = actionIndex
  317 | 
  318 |         const eventIndex = lines.findIndex(
  319 |             (line, index) => index > actionIndex && line.includes("[Event]")
  320 |         )
  321 |         expect(eventIndex).toBeGreaterThan(actionIndex)
  322 | 
  323 |         const speakIndex = lines.findIndex(
  324 |             (line, index) => index > eventIndex && line.includes("[Speak]")
  325 |         )
  326 |         expect(speakIndex).toBeGreaterThan(eventIndex)
  327 |     }
  328 | }
  329 | 
  330 | /**
  331 |  * Drives an entire Interactive session (Input Source = Inject Action)
  332 |  * with the correct click pattern for the Runner state machine.
  333 |  */
  334 | export async function completeInteractiveSessionWithInject(page: Page, steps = 5) {
  335 |     await page.getByTestId("interactive-next-button").click()
  336 | 
  337 |     for (let i = 0; i < steps; i++) {
> 338 |         await page.getByTestId("manual-recognized-yes-button").waitFor()
      |                                                                ^ Error: locator.waitFor: Test timeout of 30000ms exceeded.
  339 |         await page.getByTestId("manual-recognized-yes-button").click()
  340 |         await page.getByTestId("manual-heard-yes-button").click()
  341 |         await page.getByTestId("interactive-next-button").click()
  342 |     }
  343 | }
  344 | 
```