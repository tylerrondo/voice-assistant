# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: interactive.spec.ts >> Interactive mode (Inject Action) >> Skip Step marks the step as skipped in the summary
- Location: tests\playwright\interactive.spec.ts:44:5

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: locator.click: Test timeout of 30000ms exceeded.
Call log:
  - waiting for getByTestId('interactive-skip-button')
    - locator resolved to <button disabled id="int-btn-skip" data-testid="interactive-skip-button">⏭ Skip Step</button>
  - attempting click action
    2 × waiting for element to be visible, enabled and stable
      - element is not enabled
    - retrying click action
    - waiting 20ms
    2 × waiting for element to be visible, enabled and stable
      - element is not enabled
    - retrying click action
      - waiting 100ms
    49 × waiting for element to be visible, enabled and stable
       - element is not enabled
     - retrying click action
       - waiting 500ms

```

# Page snapshot

```yaml
- generic [ref=e3]:
  - heading "Validation Bench" [level=1] [ref=e4]
  - generic [ref=e6]:
    - heading "Test Session" [level=2] [ref=e7]
    - generic [ref=e8]:
      - generic [ref=e9]:
        - generic [ref=e10]: Tester
        - textbox "Tester" [ref=e11]: Tester-1
      - generic [ref=e12]:
        - generic [ref=e13]: UI Language
        - combobox "UI Language" [ref=e14]:
          - option "🇲🇦 الدارجة (ar-MA)"
          - option "🇫🇷 Français (fr-FR)"
          - option "🇬🇧 English (en-US)" [selected]
          - option "🇷🇺 Русский (ru-RU)"
      - generic [ref=e15]:
        - generic [ref=e16]: Voice Language
        - combobox "Voice Language" [ref=e17]:
          - option "🇲🇦 الدارجة (ar-MA)"
          - option "🇫🇷 Français (fr-FR)"
          - option "🇬🇧 English (en-US)" [selected]
          - option "🇷🇺 Русский (ru-RU)"
      - generic [ref=e18]:
        - generic [ref=e19]: Recognition Provider
        - combobox "Recognition Provider" [ref=e20]:
          - option "Browser" [selected]
          - option "OpenAI"
          - option "Azure"
          - option "Google"
          - option "Whisper"
      - generic [ref=e21]:
        - generic [ref=e22]: Speech Provider
        - combobox "Speech Provider" [ref=e23]:
          - option "Browser" [selected]
          - option "OpenAI"
          - option "Azure"
          - option "Google"
      - generic [ref=e24]:
        - generic [ref=e25]: Scenario Set
        - combobox "Scenario Set" [ref=e26]:
          - option "Automatic" [selected]
          - option "Upload"
      - generic [ref=e27]:
        - generic [ref=e28]: Build
        - textbox "Build" [ref=e29]: 1.0.0
      - generic [ref=e30]:
        - generic [ref=e31]: Commit
        - textbox "Commit" [ref=e32]: bafc789
      - generic [ref=e33]:
        - generic [ref=e34]: Environment
        - textbox "Environment" [ref=e35]: demo
      - generic [ref=e36]:
        - generic [ref=e37]: Backend URL
        - textbox "Backend URL" [ref=e38]: https://ibronevik.ru/taxi/c/gruzvill/
      - generic [ref=e39]:
        - generic [ref=e40]: Login
        - textbox "Login" [ref=e41]: testvoiceee@gmail.com
      - generic [ref=e42]:
        - generic [ref=e43]: Password
        - textbox "Password" [ref=e44]: tyler8787
  - generic [ref=e45]: "Backend: — | Mail: —"
  - generic [ref=e47]:
    - text: "Validation Mode:"
    - combobox "Validation Mode:" [ref=e48]:
      - option "Automatic"
      - option "Interactive" [selected]
  - generic [ref=e49]:
    - generic [ref=e50]: "Scenario Source:"
    - generic [ref=e51]:
      - radio "Built-in" [checked] [ref=e52]
      - text: Built-in
    - generic [ref=e53]:
      - radio "JSON File" [ref=e54]
      - text: JSON File
    - generic [ref=e55]:
      - button "Choose File..." [disabled] [ref=e56]
      - generic [ref=e57]: "Scenario File: builtin.json"
  - generic [ref=e59]:
    - text: "Input Source:"
    - combobox "Input Source:" [ref=e60]:
      - option "🎤 Browser microphone"
      - option "Inject Action (debug)" [selected]
  - generic [ref=e61]:
    - generic [ref=e62]:
      - button "Connect" [ref=e63]
      - button "▶ Start" [ref=e64]
      - button "■ Stop" [ref=e65]
      - button "▶ Run All" [ref=e66]
    - generic [ref=e67]:
      - generic [ref=e68]:
        - text: "Inject action:"
        - combobox "Inject action:" [ref=e69]:
          - option "voice.accept-order" [selected]
          - option "voice.arrived"
          - option "voice.start-trip"
          - option "voice.finish-trip"
          - option "voice.available"
      - button "Send" [ref=e70]
  - generic [ref=e71]:
    - generic [ref=e72]: "Channel State:"
    - text: — |
    - generic [ref=e73]: "Progress:"
    - text: —
  - generic [ref=e74]:
    - heading "Interactive Runner" [level=3] [ref=e75]
    - generic [ref=e76]:
      - generic [ref=e77]: "Session State:"
      - text: finished |
      - generic [ref=e78]: "Scenario:"
      - text: 0 / 0 |
      - generic [ref=e79]: "Progress:"
      - text: 100%
    - generic [ref=e80]:
      - generic [ref=e81]: Step
      - generic [ref=e82]: All scenarios completed.
      - generic [ref=e83]: "Recognized: —"
      - generic [ref=e84]: "Speech: —"
    - generic [ref=e85]:
      - button "▶ Start Step" [disabled] [ref=e86]
      - button "↺ Repeat Step" [disabled] [ref=e87]
      - button "⏭ Skip Step" [disabled] [ref=e88]
      - button "⏸ Pause" [disabled] [ref=e89]
      - button "⏵ Resume" [disabled] [ref=e90]
    - generic [ref=e91]:
      - generic [ref=e92]: Session Summary
      - generic [ref=e93]:
        - generic [ref=e94]: "Total scenarios: 1"
        - generic [ref=e95]: "Fully confirmed: 0"
        - generic [ref=e96]: "With mismatches: 0"
        - generic [ref=e97]: "Repeats: 0"
        - generic [ref=e98]: "Skipped: 1"
      - button "↻ Start New Session" [ref=e99]
  - generic [ref=e100]:
    - heading "Verification" [level=3] [ref=e101]
    - generic [ref=e102]: —
  - heading "Execution Log" [level=3] [ref=e103]
  - heading "Last Completed Report" [level=3] [ref=e105]
  - generic [ref=e107]:
    - generic [ref=e108]: "Generated at: 8/3/2026, 12:39:14 PM"
    - generic [ref=e109]:
      - strong [ref=e110]: "Status:"
      - text: FAIL
    - generic [ref=e111]:
      - strong [ref=e112]: "Tester:"
      - text: Tester-1 |
      - strong [ref=e113]: "UI Language:"
      - text: en-US |
      - strong [ref=e114]: "Voice Language:"
      - text: en-US
    - generic [ref=e115]:
      - strong [ref=e116]: "Mode:"
      - text: Interactive |
      - strong [ref=e117]: "Input Source:"
      - text: inject
    - generic [ref=e118]:
      - strong [ref=e119]: "Recognition:"
      - text: Browser |
      - strong [ref=e120]: "Speech:"
      - text: Browser |
      - strong [ref=e121]: "Scenario Set:"
      - text: automatic
    - generic [ref=e122]:
      - strong [ref=e123]: "Scenarios:"
      - text: "1 (Passed: 0, Failed: 1)"
    - generic [ref=e124]:
      - strong [ref=e125]: "Duration:"
      - text: 609 ms
  - heading "JSON Report" [level=3] [ref=e126]
  - generic [ref=e127]: "{ \"Session\": { \"tester\": \"Tester-1\", \"language\": \"en-US\", \"uiLanguage\": \"en-US\", \"startedAt\": \"2026-08-03T07:39:14.275Z\" }, \"Environment\": { \"env\": \"demo\", \"backendUrl\": \"https://ibronevik.ru/taxi/c/gruzvill\" }, \"TestConfiguration\": { \"recognitionProvider\": \"Browser\", \"speechProvider\": \"Browser\", \"scenarioSet\": \"automatic\", \"inputSource\": \"inject\" }, \"ValidationMode\": \"Interactive\", \"ScenarioSource\": \"builtin\", \"ScenarioId\": \"driver-standard-trip\", \"ScenarioName\": \"Driver Standard Trip\", \"ScenarioFile\": null, \"ScenarioStatistics\": { \"total\": 1 }, \"Verification\": { \"totalScenarios\": 1, \"passed\": 0, \"failed\": 1, \"errors\": [] }, \"ManualValidation\": { \"results\": [ { \"step\": 1, \"recognizedText\": null, \"recognizedCorrectly\": null, \"speechPlayed\": null, \"speechText\": null, \"comment\": \"\", \"repeat\": 0, \"skipped\": true, \"durationMs\": 0 } ], \"warnings\": 0, \"repeatedSteps\": 0, \"skippedSteps\": 1 }, \"ExecutionLog\": [], \"Summary\": { \"status\": \"FAIL\", \"totalScenarios\": 1, \"passed\": 0, \"failed\": 1, \"manualWarnings\": 0, \"repeatedSteps\": 0, \"skippedSteps\": 1, \"durationMs\": 609 }, \"Attachments\": [] }"
  - heading "Report History" [level=3] [ref=e128]
  - generic [ref=e130]: FAIL — 8/3/2026, 12:39:14 PM — Tester-1
  - generic [ref=e131]:
    - button [ref=e132]
    - button "Upload" [ref=e133] [cursor=pointer]
    - button "Download JSON" [ref=e134]
    - button "Send Report" [ref=e135]
```

# Test source

```ts
  1  | import { test, expect } from "@playwright/test"
  2  | import { setValidationMode, setInputSource, setSessionLanguage, completeInteractiveSessionWithInject } from "./utils/helpers"
  3  | 
  4  | /**
  5  |  * PR-10: Interactive mode regression tests.
  6  |  *
  7  |  * Uses Input Source = Inject Action so the full Interactive Runner
  8  |  * flow (Start/Next Step, confirmation buttons, Session Summary,
  9  |  * Restart) can be driven deterministically in CI, without depending
  10 |  * on a real microphone or Web Speech API availability.
  11 |  */
  12 | 
  13 | test.describe("Interactive mode (Inject Action)", () => {
  14 | 
  15 |     test.beforeEach(async ({ page }) => {
  16 |         await page.goto("/")
  17 |         await setSessionLanguage(page, "en-US")
  18 |         await setValidationMode(page, "interactive")
  19 |         await setInputSource(page, "inject")
  20 |     })
  21 | 
  22 |     test("completes all 5 steps and shows a finished session", async ({ page }) => {
  23 |         await completeInteractiveSessionWithInject(page)
  24 |         await expect(page.getByTestId("session-state")).toHaveText("finished")
  25 |         await expect(page.getByTestId("current-step")).toHaveText("5 / 5")
  26 |         await expect(page.getByTestId("progress-value")).toHaveText("100%")
  27 |     })
  28 | 
  29 |     test("Session Summary shows 5 fully confirmed scenarios with no repeats/skips", async ({ page }) => {
  30 |         await completeInteractiveSessionWithInject(page)
  31 |         const summary = page.getByTestId("interactive-summary")
  32 |         await expect(summary).toContainText("Fully confirmed: 5")
  33 |         await expect(summary).toContainText("Repeats: 0")
  34 |         await expect(summary).toContainText("Skipped: 0")
  35 |     })
  36 | 
  37 |     test("Start New Session resets the Runner back to step 1", async ({ page }) => {
  38 |         await completeInteractiveSessionWithInject(page)
  39 |         await page.getByTestId("interactive-reset-button").click()
  40 |         await expect(page.getByTestId("current-step")).toHaveText("1 / 5")
  41 |         await expect(page.getByTestId("session-state")).not.toHaveText("finished")
  42 |     })
  43 | 
  44 |     test("Skip Step marks the step as skipped in the summary", async ({ page }) => {
  45 |         await page.getByTestId("interactive-skip-button").click()
> 46 |         await page.getByTestId("interactive-skip-button").click()
     |                                                           ^ Error: locator.click: Test timeout of 30000ms exceeded.
  47 |         await page.getByTestId("interactive-skip-button").click()
  48 |         await page.getByTestId("interactive-skip-button").click()
  49 |         await page.getByTestId("interactive-skip-button").click()
  50 |         const summary = page.getByTestId("interactive-summary")
  51 |         await expect(summary).toContainText("Skipped: 5")
  52 |     })
  53 | 
  54 | })
```