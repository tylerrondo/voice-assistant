# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: automatic.spec.ts >> PR-9e.2 Automatic Suite >> 3. Execution Log >> log is created automatically with ordered Action entries
- Location: tests\playwright\automatic.spec.ts:66:9

# Error details

```
Error: expect(received).toBeGreaterThan(expected)

Expected: > 0
Received:   0
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - heading "Validation Bench" [level=1] [ref=e4]
  - generic [ref=e6]:
    - heading "Test Session" [level=2] [ref=e7]
    - generic [ref=e8]:
      - generic [ref=e9]:
        - generic [ref=e10]: Tester
        - textbox "Tester" [ref=e11]: Tester-1
      - generic [ref=e12]:
        - generic [ref=e13]: UI Language
        - combobox "UI Language" [ref=e14]:
          - option "🇲🇦 الدارجة (ar-MA)"
          - option "🇫🇷 Français (fr-FR)"
          - option "🇬🇧 English (en-US)" [selected]
          - option "🇷🇺 Русский (ru-RU)"
      - generic [ref=e15]:
        - generic [ref=e16]: Voice Language
        - combobox "Voice Language" [ref=e17]:
          - option "🇲🇦 الدارجة (ar-MA)"
          - option "🇫🇷 Français (fr-FR)"
          - option "🇬🇧 English (en-US)" [selected]
          - option "🇷🇺 Русский (ru-RU)"
      - generic [ref=e18]:
        - generic [ref=e19]: Recognition Provider
        - combobox "Recognition Provider" [ref=e20]:
          - option "Browser" [selected]
          - option "OpenAI"
          - option "Azure"
          - option "Google"
          - option "Whisper"
      - generic [ref=e21]:
        - generic [ref=e22]: Speech Provider
        - combobox "Speech Provider" [ref=e23]:
          - option "Browser" [selected]
          - option "OpenAI"
          - option "Azure"
          - option "Google"
      - generic [ref=e24]:
        - generic [ref=e25]: Scenario Set
        - combobox "Scenario Set" [ref=e26]:
          - option "Automatic" [selected]
          - option "Upload"
      - generic [ref=e27]:
        - generic [ref=e28]: Build
        - textbox "Build" [ref=e29]: 1.0.0
      - generic [ref=e30]:
        - generic [ref=e31]: Commit
        - textbox "Commit" [ref=e32]: bafc789
      - generic [ref=e33]:
        - generic [ref=e34]: Environment
        - textbox "Environment" [ref=e35]: demo
      - generic [ref=e36]:
        - generic [ref=e37]: Backend URL
        - textbox "Backend URL" [ref=e38]: https://ibronevik.ru/taxi/c/gruzvill/
      - generic [ref=e39]:
        - generic [ref=e40]: Login
        - textbox "Login" [ref=e41]: testvoiceee@gmail.com
      - generic [ref=e42]:
        - generic [ref=e43]: Password
        - textbox "Password" [ref=e44]: tyler8787
  - generic [ref=e45]: "Backend: — | Mail: —"
  - generic [ref=e47]:
    - text: "Validation Mode:"
    - combobox "Validation Mode:" [ref=e48]:
      - option "Automatic" [selected]
      - option "Interactive"
  - generic [ref=e49]:
    - generic [ref=e50]: "Scenario Source:"
    - generic [ref=e51]:
      - radio "Built-in" [checked] [ref=e52]
      - text: Built-in
    - generic [ref=e53]:
      - radio "JSON File" [ref=e54]
      - text: JSON File
    - generic [ref=e55]:
      - button "Choose File..." [disabled] [ref=e56]
      - generic [ref=e57]: "Scenario File: builtin.json"
  - generic [ref=e58]:
    - generic [ref=e59]:
      - button "Connect" [ref=e60]
      - button "▶ Start" [ref=e61]
      - button "■ Stop" [ref=e62]
      - button "▶ Run All" [ref=e63]
    - generic [ref=e64]: 🎤 Idle
  - generic [ref=e65]:
    - generic [ref=e66]: "Channel State:"
    - text: — |
    - generic [ref=e67]: "Progress:"
    - text: —
  - generic [ref=e68]:
    - heading "Verification" [level=3] [ref=e69]
    - generic [ref=e70]: —
  - heading "Execution Log" [level=3] [ref=e71]
  - heading "Last Completed Report" [level=3] [ref=e73]
  - generic [ref=e74]: Run All or finish an Interactive session to view a report here.
  - heading "JSON Report" [level=3] [ref=e75]
  - heading "Report History" [level=3] [ref=e77]
  - generic [ref=e78]: —
  - generic [ref=e79]:
    - button [ref=e80]
    - button "Upload" [ref=e81] [cursor=pointer]
    - button "Download JSON" [ref=e82]
    - button "Send Report" [ref=e83]
```

# Test source

```ts
  1   | import { test, expect } from "@playwright/test"
  2   | import {
  3   |     runAll,
  4   |     runAllWithProgressTracking,
  5   |     readSessionConfig,
  6   |     readJsonReport,
  7   |     downloadJsonReport,
  8   |     dismissNextDialog,
  9   |     setupBackendMocks,
  10  |     assertRequiredReportSections,
  11  |     assertSummaryConsistency,
  12  |     assertConfigurationMatchesSession,
  13  |     assertExecutionLog,
  14  |     assertAutomaticProgressSequence,
  15  |     waitForAutomaticRunInProgress,
  16  |     setSessionLanguage,
  17  |     type ValidationReportJson
  18  | } from "./utils/helpers"
  19  | 
  20  | /**
  21  |  * PR-9e.2 — Playwright Automatic Suite.
  22  |  *
  23  |  * Covers Automatic Runner end-to-end through the public Validation Bench
  24  |  * UI and JSON report surface only. Uses Inject Action (no microphone).
  25  |  */
  26  | 
  27  | test.describe("PR-9e.2 Automatic Suite", () => {
  28  | 
  29  |     test.beforeEach(async ({ page }) => {
  30  |         await page.goto("/")
  31  |         await setSessionLanguage(page, "en-US")
  32  |         await expect(page.getByTestId("validation-mode")).toHaveValue("automatic")
  33  |     })
  34  | 
  35  |     test.describe("1. Scenario execution", () => {
  36  | 
  37  |         test("Run All completes every built-in scenario and produces a report", async ({ page }) => {
  38  |             const config = await readSessionConfig(page)
  39  | 
  40  |             await runAll(page)
  41  | 
  42  |             await expect(page.getByTestId("verification-panel")).toContainText(/PASS/)
  43  |             const report = await readJsonReport(page)
  44  |             expect(report.Summary.totalScenarios).toBeGreaterThan(0)
  45  |             expect(report.Summary.passed).toBe(report.Summary.totalScenarios)
  46  |             expect(report.Summary.failed).toBe(0)
  47  |             expect(report.Session.startedAt).toMatch(/^\d{4}-\d{2}-\d{2}T/)
  48  |             assertConfigurationMatchesSession(report, config)
  49  |         })
  50  | 
  51  |     })
  52  | 
  53  |     test.describe("2. Progress", () => {
  54  | 
  55  |         test("progress moves from idle through running scenarios to Done", async ({ page }) => {
  56  |             expect(await page.getByTestId("automatic-progress").innerText()).toBe("—")
  57  | 
  58  |             const states = await runAllWithProgressTracking(page)
  59  |             assertAutomaticProgressSequence(states)
  60  |         })
  61  | 
  62  |     })
  63  | 
  64  |     test.describe("3. Execution Log", () => {
  65  | 
  66  |         test("log is created automatically with ordered Action entries", async ({ page }) => {
  67  |             await runAll(page)
  68  | 
  69  |             const logText = await page.getByTestId("execution-log").innerText()
> 70  |             expect(logText.trim().length).toBeGreaterThan(0)
      |                                           ^ Error: expect(received).toBeGreaterThan(expected)
  71  | 
  72  |             const report = await readJsonReport(page)
  73  |             assertExecutionLog(report, logText)
  74  |         })
  75  | 
  76  |     })
  77  | 
  78  |     test.describe("4. Report sections", () => {
  79  | 
  80  |         test("report contains Session, Configuration, Summary, Verification, and Execution Log", async ({ page }) => {
  81  |             await runAll(page)
  82  | 
  83  |             const report = await readJsonReport(page)
  84  |             assertRequiredReportSections(report)
  85  | 
  86  |             expect(typeof report.Session.tester).toBe("string")
  87  |             expect(typeof report.TestConfiguration.recognitionProvider).toBe("string")
  88  |             expect(typeof report.Summary.status).toBe("string")
  89  |             expect(typeof report.Verification.totalScenarios).toBe("number")
  90  |             expect(report.ExecutionLog.length).toBeGreaterThan(0)
  91  |         })
  92  | 
  93  |     })
  94  | 
  95  |     test.describe("5. Summary consistency", () => {
  96  | 
  97  |         test("Summary totals are internally consistent with Verification", async ({ page }) => {
  98  |             await runAll(page)
  99  | 
  100 |             const report = await readJsonReport(page)
  101 |             assertSummaryConsistency(report)
  102 |         })
  103 | 
  104 |     })
  105 | 
  106 |     test.describe("6. Configuration", () => {
  107 | 
  108 |         test("report preserves the launch configuration from Session Panel", async ({ page }) => {
  109 |             await page.getByTestId("session-voice-language").selectOption("ru-RU")
  110 |             await page.getByTestId("session-recognition-provider").selectOption("OpenAI")
  111 |             await page.getByTestId("session-speech-provider").selectOption("Azure")
  112 |             await page.getByTestId("session-scenario-set").selectOption("upload")
  113 | 
  114 |             const config = await readSessionConfig(page)
  115 |             await runAll(page)
  116 | 
  117 |             const report = await readJsonReport(page)
  118 |             assertConfigurationMatchesSession(report, config)
  119 |         })
  120 | 
  121 |     })
  122 | 
  123 |     test.describe("7. Verification", () => {
  124 | 
  125 |         test("verification results exist and match the scenario count", async ({ page }) => {
  126 |             await runAll(page)
  127 | 
  128 |             const report = await readJsonReport(page)
  129 |             expect(report.Verification.totalScenarios).toBe(report.Summary.totalScenarios)
  130 |             expect(report.Verification.passed + report.Verification.failed).toBe(report.Verification.totalScenarios)
  131 |             expect(Array.isArray(report.Verification.errors)).toBe(true)
  132 |             expect(report.Verification.errors.length).toBe(0)
  133 | 
  134 |             await expect(page.getByTestId("verification-panel")).toContainText(
  135 |                 new RegExp(`PASS \\(${report.Verification.passed}/${report.Verification.totalScenarios}\\)`)
  136 |             )
  137 |         })
  138 | 
  139 |     })
  140 | 
  141 |     test.describe("8. Download JSON", () => {
  142 | 
  143 |         test("download produces valid JSON matching the on-screen report structure", async ({ page }) => {
  144 |             await runAll(page)
  145 | 
  146 |             const uiReport = await readJsonReport(page)
  147 |             const downloaded = await downloadJsonReport(page)
  148 | 
  149 |             expect(downloaded).toEqual(uiReport)
  150 |             assertRequiredReportSections(downloaded)
  151 |             assertSummaryConsistency(downloaded)
  152 |         })
  153 | 
  154 |     })
  155 | 
  156 |     test.describe("9. Send Report", () => {
  157 | 
  158 |         test("Send Report transmits the same object as Download JSON", async ({ page }) => {
  159 |             const capture: { sentReport?: ValidationReportJson } = {}
  160 |             await setupBackendMocks(page, capture)
  161 | 
  162 |             await page.getByTestId("connect-button").click()
  163 |             await expect(page.getByTestId("connection-status")).toContainText("Connected")
  164 | 
  165 |             await runAll(page)
  166 |             const uiReport = await readJsonReport(page)
  167 |             const downloaded = await downloadJsonReport(page)
  168 | 
  169 |             const dialogPromise = dismissNextDialog(page)
  170 |             await page.getByTestId("send-report-button").click()
```