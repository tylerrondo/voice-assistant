# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: automatic.spec.ts >> PR-9e.2 Automatic Suite >> 1. Scenario execution >> Run All completes every built-in scenario and produces a report
- Location: tests\playwright\automatic.spec.ts:37:9

# Error details

```
Error: expect(locator).toContainText(expected) failed

Locator: getByTestId('verification-panel')
Expected pattern: /PASS/
Received string:  "—"
Timeout: 5000ms

Call log:
  - Expect "toContainText" with timeout 5000ms
  - waiting for getByTestId('verification-panel')
    13 × locator resolved to <div id="verification-result" data-testid="verification-panel">—</div>
       - unexpected value "—"

```

```yaml
- text: —
```

# Test source

```ts
  1   | import { test, expect } from "@playwright/test"
  2   | import {
  3   |     runAll,
  4   |     runAllWithProgressTracking,
  5   |     readSessionConfig,
  6   |     readJsonReport,
  7   |     downloadJsonReport,
  8   |     dismissNextDialog,
  9   |     setupBackendMocks,
  10  |     assertRequiredReportSections,
  11  |     assertSummaryConsistency,
  12  |     assertConfigurationMatchesSession,
  13  |     assertExecutionLog,
  14  |     assertAutomaticProgressSequence,
  15  |     waitForAutomaticRunInProgress,
  16  |     setSessionLanguage,
  17  |     type ValidationReportJson
  18  | } from "./utils/helpers"
  19  | 
  20  | /**
  21  |  * PR-9e.2 — Playwright Automatic Suite.
  22  |  *
  23  |  * Covers Automatic Runner end-to-end through the public Validation Bench
  24  |  * UI and JSON report surface only. Uses Inject Action (no microphone).
  25  |  */
  26  | 
  27  | test.describe("PR-9e.2 Automatic Suite", () => {
  28  | 
  29  |     test.beforeEach(async ({ page }) => {
  30  |         await page.goto("/")
  31  |         await setSessionLanguage(page, "en-US")
  32  |         await expect(page.getByTestId("validation-mode")).toHaveValue("automatic")
  33  |     })
  34  | 
  35  |     test.describe("1. Scenario execution", () => {
  36  | 
  37  |         test("Run All completes every built-in scenario and produces a report", async ({ page }) => {
  38  |             const config = await readSessionConfig(page)
  39  | 
  40  |             await runAll(page)
  41  | 
> 42  |             await expect(page.getByTestId("verification-panel")).toContainText(/PASS/)
      |                                                                  ^ Error: expect(locator).toContainText(expected) failed
  43  |             const report = await readJsonReport(page)
  44  |             expect(report.Summary.totalScenarios).toBeGreaterThan(0)
  45  |             expect(report.Summary.passed).toBe(report.Summary.totalScenarios)
  46  |             expect(report.Summary.failed).toBe(0)
  47  |             expect(report.Session.startedAt).toMatch(/^\d{4}-\d{2}-\d{2}T/)
  48  |             assertConfigurationMatchesSession(report, config)
  49  |         })
  50  | 
  51  |     })
  52  | 
  53  |     test.describe("2. Progress", () => {
  54  | 
  55  |         test("progress moves from idle through running scenarios to Done", async ({ page }) => {
  56  |             expect(await page.getByTestId("automatic-progress").innerText()).toBe("—")
  57  | 
  58  |             const states = await runAllWithProgressTracking(page)
  59  |             assertAutomaticProgressSequence(states)
  60  |         })
  61  | 
  62  |     })
  63  | 
  64  |     test.describe("3. Execution Log", () => {
  65  | 
  66  |         test("log is created automatically with ordered Action entries", async ({ page }) => {
  67  |             await runAll(page)
  68  | 
  69  |             const logText = await page.getByTestId("execution-log").innerText()
  70  |             expect(logText.trim().length).toBeGreaterThan(0)
  71  | 
  72  |             const report = await readJsonReport(page)
  73  |             assertExecutionLog(report, logText)
  74  |         })
  75  | 
  76  |     })
  77  | 
  78  |     test.describe("4. Report sections", () => {
  79  | 
  80  |         test("report contains Session, Configuration, Summary, Verification, and Execution Log", async ({ page }) => {
  81  |             await runAll(page)
  82  | 
  83  |             const report = await readJsonReport(page)
  84  |             assertRequiredReportSections(report)
  85  | 
  86  |             expect(typeof report.Session.tester).toBe("string")
  87  |             expect(typeof report.TestConfiguration.recognitionProvider).toBe("string")
  88  |             expect(typeof report.Summary.status).toBe("string")
  89  |             expect(typeof report.Verification.totalScenarios).toBe("number")
  90  |             expect(report.ExecutionLog.length).toBeGreaterThan(0)
  91  |         })
  92  | 
  93  |     })
  94  | 
  95  |     test.describe("5. Summary consistency", () => {
  96  | 
  97  |         test("Summary totals are internally consistent with Verification", async ({ page }) => {
  98  |             await runAll(page)
  99  | 
  100 |             const report = await readJsonReport(page)
  101 |             assertSummaryConsistency(report)
  102 |         })
  103 | 
  104 |     })
  105 | 
  106 |     test.describe("6. Configuration", () => {
  107 | 
  108 |         test("report preserves the launch configuration from Session Panel", async ({ page }) => {
  109 |             await page.getByTestId("session-voice-language").selectOption("ru-RU")
  110 |             await page.getByTestId("session-recognition-provider").selectOption("OpenAI")
  111 |             await page.getByTestId("session-speech-provider").selectOption("Azure")
  112 |             await page.getByTestId("session-scenario-set").selectOption("upload")
  113 | 
  114 |             const config = await readSessionConfig(page)
  115 |             await runAll(page)
  116 | 
  117 |             const report = await readJsonReport(page)
  118 |             assertConfigurationMatchesSession(report, config)
  119 |         })
  120 | 
  121 |     })
  122 | 
  123 |     test.describe("7. Verification", () => {
  124 | 
  125 |         test("verification results exist and match the scenario count", async ({ page }) => {
  126 |             await runAll(page)
  127 | 
  128 |             const report = await readJsonReport(page)
  129 |             expect(report.Verification.totalScenarios).toBe(report.Summary.totalScenarios)
  130 |             expect(report.Verification.passed + report.Verification.failed).toBe(report.Verification.totalScenarios)
  131 |             expect(Array.isArray(report.Verification.errors)).toBe(true)
  132 |             expect(report.Verification.errors.length).toBe(0)
  133 | 
  134 |             await expect(page.getByTestId("verification-panel")).toContainText(
  135 |                 new RegExp(`PASS \\(${report.Verification.passed}/${report.Verification.totalScenarios}\\)`)
  136 |             )
  137 |         })
  138 | 
  139 |     })
  140 | 
  141 |     test.describe("8. Download JSON", () => {
  142 | 
```