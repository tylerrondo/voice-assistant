# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: driver-standard-trip.spec.ts >> PR-13: Driver Standard Trip scenario coverage >> Reset clears Interactive session state completely and restarts from the first scenario
- Location: tests\playwright\driver-standard-trip.spec.ts:236:5

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: locator.waitFor: Test timeout of 30000ms exceeded.
Call log:
  - waiting for getByTestId('manual-recognized-yes-button') to be visible
    62 × locator resolved to hidden <button id="int-btn-recognized-yes" data-testid="manual-recognized-yes-button">✓ Correct</button>

```

# Page snapshot

```yaml
- generic [ref=e3]:
  - heading "Validation Bench" [level=1] [ref=e4]
  - generic [ref=e6]:
    - heading "Test Session" [level=2] [ref=e7]
    - generic [ref=e8]:
      - generic [ref=e9]:
        - generic [ref=e10]: Tester
        - textbox "Tester" [ref=e11]: Tester-1
      - generic [ref=e12]:
        - generic [ref=e13]: UI Language
        - combobox "UI Language" [ref=e14]:
          - option "🇲🇦 الدارجة (ar-MA)"
          - option "🇫🇷 Français (fr-FR)"
          - option "🇬🇧 English (en-US)" [selected]
          - option "🇷🇺 Русский (ru-RU)"
      - generic [ref=e15]:
        - generic [ref=e16]: Voice Language
        - combobox "Voice Language" [ref=e17]:
          - option "🇲🇦 الدارجة (ar-MA)"
          - option "🇫🇷 Français (fr-FR)"
          - option "🇬🇧 English (en-US)" [selected]
          - option "🇷🇺 Русский (ru-RU)"
      - generic [ref=e18]:
        - generic [ref=e19]: Recognition Provider
        - combobox "Recognition Provider" [ref=e20]:
          - option "Browser" [selected]
          - option "OpenAI"
          - option "Azure"
          - option "Google"
          - option "Whisper"
      - generic [ref=e21]:
        - generic [ref=e22]: Speech Provider
        - combobox "Speech Provider" [ref=e23]:
          - option "Browser" [selected]
          - option "OpenAI"
          - option "Azure"
          - option "Google"
      - generic [ref=e24]:
        - generic [ref=e25]: Scenario Set
        - combobox "Scenario Set" [ref=e26]:
          - option "Automatic" [selected]
          - option "Upload"
      - generic [ref=e27]:
        - generic [ref=e28]: Build
        - textbox "Build" [ref=e29]: 1.0.0
      - generic [ref=e30]:
        - generic [ref=e31]: Commit
        - textbox "Commit" [ref=e32]: bafc789
      - generic [ref=e33]:
        - generic [ref=e34]: Environment
        - textbox "Environment" [ref=e35]: demo
      - generic [ref=e36]:
        - generic [ref=e37]: Backend URL
        - textbox "Backend URL" [ref=e38]: https://ibronevik.ru/taxi/c/gruzvill/
      - generic [ref=e39]:
        - generic [ref=e40]: Login
        - textbox "Login" [ref=e41]: testvoiceee@gmail.com
      - generic [ref=e42]:
        - generic [ref=e43]: Password
        - textbox "Password" [ref=e44]: tyler8787
  - generic [ref=e45]: "Backend: — | Mail: —"
  - generic [ref=e47]:
    - text: "Validation Mode:"
    - combobox "Validation Mode:" [ref=e48]:
      - option "Automatic"
      - option "Interactive" [selected]
  - generic [ref=e49]:
    - generic [ref=e50]: "Scenario Source:"
    - generic [ref=e51]:
      - radio "Built-in" [checked] [ref=e52]
      - text: Built-in
    - generic [ref=e53]:
      - radio "JSON File" [ref=e54]
      - text: JSON File
    - generic [ref=e55]:
      - button "Choose File..." [disabled] [ref=e56]
      - generic [ref=e57]: "Scenario File: builtin.json"
  - generic [ref=e59]:
    - text: "Input Source:"
    - combobox "Input Source:" [ref=e60]:
      - option "🎤 Browser microphone"
      - option "Inject Action (debug)" [selected]
  - generic [ref=e61]:
    - generic [ref=e62]:
      - button "Connect" [ref=e63]
      - button "▶ Start" [ref=e64]
      - button "■ Stop" [ref=e65]
      - button "▶ Run All" [ref=e66]
    - generic [ref=e67]:
      - generic [ref=e68]:
        - text: "Inject action:"
        - combobox "Inject action:" [ref=e69]:
          - option "voice.accept-order" [selected]
          - option "voice.arrived"
          - option "voice.start-trip"
          - option "voice.finish-trip"
          - option "voice.available"
      - button "Send" [ref=e70]
  - generic [ref=e71]:
    - generic [ref=e72]: "Channel State:"
    - text: — |
    - generic [ref=e73]: "Progress:"
    - text: —
  - generic [ref=e74]:
    - heading "Interactive Runner" [level=3] [ref=e75]
    - generic [ref=e76]:
      - generic [ref=e77]: "Session State:"
      - text: finished |
      - generic [ref=e78]: "Scenario:"
      - text: 0 / 0 |
      - generic [ref=e79]: "Progress:"
      - text: 100%
    - generic [ref=e80]:
      - generic [ref=e81]: Step
      - generic [ref=e82]: All scenarios completed.
      - generic [ref=e83]: "Recognized: —"
      - generic [ref=e84]: "Speech: interaction.unhandled-action"
    - generic [ref=e85]:
      - button "▶ Start Step" [disabled] [ref=e86]
      - button "↺ Repeat Step" [disabled] [ref=e87]
      - button "⏭ Skip Step" [disabled] [ref=e88]
      - button "⏸ Pause" [disabled] [ref=e89]
      - button "⏵ Resume" [disabled] [ref=e90]
    - generic [ref=e91]:
      - generic [ref=e92]: Session Summary
      - generic [ref=e93]:
        - generic [ref=e94]: "Total scenarios: 1"
        - generic [ref=e95]: "Fully confirmed: 1"
        - generic [ref=e96]: "With mismatches: 0"
        - generic [ref=e97]: "Repeats: 0"
        - generic [ref=e98]: "Skipped: 0"
      - button "↻ Start New Session" [ref=e99]
  - generic [ref=e100]:
    - heading "Verification" [level=3] [ref=e101]
    - generic [ref=e102]: —
  - heading "Execution Log" [level=3] [ref=e103]
  - generic [ref=e104]: "[Action] {\"payload\":{}} [Event] {\"type\":\"interaction.unhandled-action\",\"payload\":{}} [Speak] {\"text\":\"interaction.unhandled-action\"}"
  - heading "Last Completed Report" [level=3] [ref=e105]
  - generic [ref=e107]:
    - generic [ref=e108]: "Generated at: 8/3/2026, 12:36:58 PM"
    - generic [ref=e109]:
      - strong [ref=e110]: "Status:"
      - text: PASS
    - generic [ref=e111]:
      - strong [ref=e112]: "Tester:"
      - text: Tester-1 |
      - strong [ref=e113]: "UI Language:"
      - text: en-US |
      - strong [ref=e114]: "Voice Language:"
      - text: en-US
    - generic [ref=e115]:
      - strong [ref=e116]: "Mode:"
      - text: Interactive |
      - strong [ref=e117]: "Input Source:"
      - text: inject
    - generic [ref=e118]:
      - strong [ref=e119]: "Recognition:"
      - text: Browser |
      - strong [ref=e120]: "Speech:"
      - text: Browser |
      - strong [ref=e121]: "Scenario Set:"
      - text: automatic
    - generic [ref=e122]:
      - strong [ref=e123]: "Scenarios:"
      - text: "1 (Passed: 1, Failed: 0)"
    - generic [ref=e124]:
      - strong [ref=e125]: "Duration:"
      - text: 1253 ms
  - heading "JSON Report" [level=3] [ref=e126]
  - generic [ref=e127]: "{ \"Session\": { \"tester\": \"Tester-1\", \"language\": \"en-US\", \"uiLanguage\": \"en-US\", \"startedAt\": \"2026-08-03T07:36:56.783Z\" }, \"Environment\": { \"env\": \"demo\", \"backendUrl\": \"https://ibronevik.ru/taxi/c/gruzvill\" }, \"TestConfiguration\": { \"recognitionProvider\": \"Browser\", \"speechProvider\": \"Browser\", \"scenarioSet\": \"automatic\", \"inputSource\": \"inject\" }, \"ValidationMode\": \"Interactive\", \"ScenarioSource\": \"builtin\", \"ScenarioId\": \"driver-standard-trip\", \"ScenarioName\": \"Driver Standard Trip\", \"ScenarioFile\": null, \"ScenarioStatistics\": { \"total\": 1 }, \"Verification\": { \"totalScenarios\": 1, \"passed\": 1, \"failed\": 0, \"errors\": [] }, \"ManualValidation\": { \"results\": [ { \"step\": 1, \"recognizedText\": null, \"recognizedCorrectly\": true, \"speechPlayed\": true, \"speechText\": \"interaction.unhandled-action\", \"comment\": \"\", \"repeat\": 0, \"skipped\": false, \"durationMs\": 12 } ], \"warnings\": 0, \"repeatedSteps\": 0, \"skippedSteps\": 0 }, \"ExecutionLog\": [ { \"timestamp\": \"2026-08-03T07:36:57.332Z\", \"kind\": \"Action\", \"payload\": { \"payload\": {} } }, { \"timestamp\": \"2026-08-03T07:36:57.340Z\", \"kind\": \"Event\", \"payload\": { \"type\": \"interaction.unhandled-action\", \"payload\": {} } }, { \"timestamp\": \"2026-08-03T07:36:57.341Z\", \"kind\": \"Speak\", \"payload\": { \"text\": \"interaction.unhandled-action\" } } ], \"Summary\": { \"status\": \"PASS\", \"totalScenarios\": 1, \"passed\": 1, \"failed\": 0, \"manualWarnings\": 0, \"repeatedSteps\": 0, \"skippedSteps\": 0, \"durationMs\": 1253 }, \"Attachments\": [] }"
  - heading "Report History" [level=3] [ref=e128]
  - generic [ref=e130]: PASS — 8/3/2026, 12:36:58 PM — Tester-1
  - generic [ref=e131]:
    - button [ref=e132]
    - button "Upload" [ref=e133] [cursor=pointer]
    - button "Download JSON" [ref=e134]
    - button "Send Report" [ref=e135]
```

# Test source

```ts
  144 |             let logText = await page.getByTestId("execution-log").innerText()
  145 |             expect(logText).toContain(TRIGGERS_IN_ORDER[0])
  146 |             let previousLogLength = countNonEmptyLines(logText)
  147 | 
  148 |             for (let i = 0; i < TOTAL; i++) {
  149 |                 await page.getByTestId("manual-recognized-yes-button").click()
  150 |                 await page.getByTestId("manual-heard-yes-button").click()
  151 |                 await page.getByTestId("interactive-next-button").click()
  152 | 
  153 |                 const isLast = i === TOTAL - 1
  154 | 
  155 |                 if (isLast) {
  156 |                     // Committing the last scenario finishes the session.
  157 |                     await expect(page.getByTestId("session-state")).toHaveAttribute("data-state", "finished")
  158 |                     await expect(page.getByTestId("current-step")).toHaveText(`${TOTAL} / ${TOTAL}`)
  159 |                     await expect(page.getByTestId("progress-value")).toHaveText("100%")
  160 |                 } else {
  161 |                     // Every non-final "Next Step" both commits the
  162 |                     // current scenario AND auto-starts the next one, so
  163 |                     // confirmation buttons for the next step appear
  164 |                     // without an extra click.
  165 |                     await page.getByTestId("manual-recognized-yes-button").waitFor()
  166 |                     await expect(page.getByTestId("session-state")).toHaveAttribute("data-state", "waiting-tester")
  167 |                     await expect(page.getByTestId("current-step")).toHaveText(`${i + 2} / ${TOTAL}`)
  168 |                     await expect(page.getByTestId("progress-value")).toHaveText(`${Math.round((i + 1) / TOTAL * 100)}%`)
  169 |                 }
  170 | 
  171 |                 // Execution Log grew and now contains this step's trigger.
  172 |                 logText = await page.getByTestId("execution-log").innerText()
  173 |                 const currentLogLength = countNonEmptyLines(logText)
  174 |                 expect(currentLogLength).toBeGreaterThan(previousLogLength)
  175 |                 expect(logText).toContain(TRIGGERS_IN_ORDER[i])
  176 |                 previousLogLength = currentLogLength
  177 |             }
  178 | 
  179 |             const report = await readJsonReport(page)
  180 |             expect(report.ScenarioSource).toBe("builtin")
  181 |             expect(report.ScenarioId).toBe(BUILTIN_SET.id)
  182 |             expect(report.ScenarioName).toBe(BUILTIN_SET.name)
  183 |             expect(report.ScenarioFile).toBeNull()
  184 |         })
  185 | 
  186 |     })
  187 | 
  188 |     test("Execution Log preserves strict scenario order in both modes", async ({ page }) => {
  189 |         await page.goto("/")
  190 |         await setSessionLanguage(page, "en-US")
  191 | 
  192 |         await runAll(page)
  193 |         const automaticLog = await page.getByTestId("execution-log").innerText()
  194 |         assertStrictTriggerOrder(automaticLog, TRIGGERS_IN_ORDER)
  195 | 
  196 |         await page.goto("/")
  197 |         await setSessionLanguage(page, "en-US")
  198 |         await setValidationMode(page, "interactive")
  199 |         await setInputSource(page, "inject")
  200 | 
  201 |         for (let i = 0; i < TOTAL; i++) {
  202 |             await page.getByTestId("interactive-next-button").click()
  203 |             await page.getByTestId("manual-recognized-yes-button").waitFor()
  204 |             await page.getByTestId("manual-recognized-yes-button").click()
  205 |             await page.getByTestId("manual-heard-yes-button").click()
  206 |         }
  207 |         await page.getByTestId("interactive-next-button").click()
  208 | 
  209 |         const interactiveLog = await page.getByTestId("execution-log").innerText()
  210 |         assertStrictTriggerOrder(interactiveLog, TRIGGERS_IN_ORDER)
  211 |     })
  212 | 
  213 |     test("running the scenario twice does not leak Execution Log state between runs", async ({ page }) => {
  214 |         await page.goto("/")
  215 |         await setSessionLanguage(page, "en-US")
  216 | 
  217 |         await runAll(page)
  218 |         const firstReport = await readJsonReport(page)
  219 | 
  220 |         await runAll(page)
  221 |         const secondReport = await readJsonReport(page)
  222 |         const secondLog = await page.getByTestId("execution-log").innerText()
  223 | 
  224 |         // Results are consistent across runs.
  225 |         expect(secondReport.Summary.status).toBe(firstReport.Summary.status)
  226 |         expect(secondReport.Summary.totalScenarios).toBe(firstReport.Summary.totalScenarios)
  227 |         expect(secondReport.ScenarioId).toBe(firstReport.ScenarioId)
  228 | 
  229 |         // The second run's live Execution Log is a fresh log with
  230 |         // exactly TOTAL actions, not the first run's entries plus new ones.
  231 |         const secondActionLines = secondLog.split("\n").filter(l => l.includes("[Action]"))
  232 |         expect(secondActionLines.length).toBe(TOTAL)
  233 |         assertStrictTriggerOrder(secondLog, TRIGGERS_IN_ORDER)
  234 |     })
  235 | 
  236 |     test("Reset clears Interactive session state completely and restarts from the first scenario", async ({ page }) => {
  237 |         await page.goto("/")
  238 |         await setSessionLanguage(page, "en-US")
  239 |         await setValidationMode(page, "interactive")
  240 |         await setInputSource(page, "inject")
  241 | 
  242 |         for (let i = 0; i < TOTAL; i++) {
  243 |             await page.getByTestId("interactive-next-button").click()
> 244 |             await page.getByTestId("manual-recognized-yes-button").waitFor()
      |                                                                    ^ Error: locator.waitFor: Test timeout of 30000ms exceeded.
  245 |             await page.getByTestId("manual-recognized-yes-button").click()
  246 |             await page.getByTestId("manual-heard-yes-button").click()
  247 |         }
  248 |         await page.getByTestId("interactive-next-button").click()
  249 |         await expect(page.getByTestId("session-state")).toHaveAttribute("data-state", "finished")
  250 | 
  251 |         await page.getByTestId("interactive-reset-button").click()
  252 | 
  253 |         // Reset restarts the session immediately — it re-enters the same
  254 |         // state a fresh "switch to Interactive" produces (see the test
  255 |         // above), not a separate idle state.
  256 |         await expect(page.getByTestId("session-state")).not.toHaveAttribute("data-state", "finished")
  257 |         await expect(page.getByTestId("session-state")).toHaveAttribute("data-state", "running")
  258 |         await expect(page.getByTestId("current-step")).toHaveText(`1 / ${TOTAL}`)
  259 |         await expect(page.getByTestId("progress-value")).toHaveText("0%")
  260 | 
  261 |         // Execution Log was cleared and now only has the marker for the
  262 |         // freshly loaded first scenario — no [Action] entries yet (step 1
  263 |         // hasn't been performed again), and nothing from the finished run.
  264 |         const logAfterReset = await page.getByTestId("execution-log").innerText()
  265 |         expect(logAfterReset).not.toContain("[Action]")
  266 |         expect(logAfterReset).toContain(TRIGGERS_IN_ORDER[0])
  267 |         expect(logAfterReset).not.toContain(TRIGGERS_IN_ORDER[TOTAL - 1])
  268 | 
  269 |         // A new run starts from the first scenario again.
  270 |         await page.getByTestId("interactive-next-button").click()
  271 |         await page.getByTestId("manual-recognized-yes-button").waitFor()
  272 |         await expect(page.getByTestId("current-step")).toHaveText(`1 / ${TOTAL}`)
  273 |         const logText = await page.getByTestId("execution-log").innerText()
  274 |         expect(logText).toContain("[Action]")
  275 |         expect(logText).toContain(TRIGGERS_IN_ORDER[0])
  276 |         expect(logText).not.toContain(TRIGGERS_IN_ORDER[TOTAL - 1])
  277 |     })
  278 | 
  279 |     // --- Negative-path coverage: NOT implemented, see docs/rfc/PR-13.md ---
  280 |     //
  281 |     // Per review, a negative test ("one step is broken -> FAIL is
  282 |     // reported -> execution stops correctly") was requested. This is
  283 |     // intentionally NOT written here: Validation Bench's Automatic
  284 |     // verification currently has no real per-scenario pass/fail
  285 |     // evaluation at all. `verification.passed` is unconditionally set
  286 |     // to `totalScenarios` and `failed` to `0` (see App.ts, the Run All
  287 |     // handler) — there is no code path that ever produces FAIL. Writing
  288 |     // a test that asserts "FAIL is reported" against that code would
  289 |     // either be a no-op that can never fail, or would require silently
  290 |     // adding fake failure-detection logic as a side effect of a test
  291 |     // file, which would misrepresent what this PR actually covers.
  292 |     // A real negative test needs a prerequisite change to the
  293 |     // Automatic verification pipeline (an actual pass/fail check per
  294 |     // scenario) — flagged as follow-up, not implemented here.
  295 | 
  296 | })
  297 | 
  298 | /** Asserts that each trigger's [Action] entry appears in the given order in the log text. */
  299 | function assertStrictTriggerOrder(logText: string, triggersInOrder: string[]) {
  300 |     const lines = logText.split("\n").filter(l => l.trim().length > 0)
  301 |     let lastIndex = -1
  302 |     for (const trigger of triggersInOrder) {
  303 |         const index = lines.findIndex(line => line.includes("[Action]") && line.includes(trigger))
  304 |         expect(index).toBeGreaterThan(lastIndex)
  305 |         lastIndex = index
  306 |     }
  307 | }
  308 | 
  309 | function countNonEmptyLines(text: string): number {
  310 |     return text.split("\n").filter(l => l.trim().length > 0).length
  311 | }
  312 | 
```